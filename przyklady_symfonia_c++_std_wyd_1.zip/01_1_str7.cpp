//***************************************************
// Program z paragrafu  1.1 (str 7)
//***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream> 
int main() 
{ 
	std::cout << "Witamy na pokladzie"; 
}



/************************************************************
Uwaga: MSVC 6.0 nieslusznie ostrzega tu o nieobecnosci instrukcji return. 
Zignorowac!

************************************************************/
