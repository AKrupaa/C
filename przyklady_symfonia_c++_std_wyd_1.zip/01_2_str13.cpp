//***************************************************
// Program z paragrafu  1.2 (str 13)
//***************************************************
// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


/* ----------------------------------------------------------- 
Program na przeliczanie wysokosci podanej 
w stopach na wysokosc w metrach. 
Cwiczymy tu operacje wczytywania z klawiatury 
i wypisywania na ekranie 
------------------------------------------------------------*/ 
#include <iostream> 
int main() 
{ 
	int 		stopy;				// Do przechowania danej wejsciowej
	double 	metry;									// Do wpisania wyniku 
	double 	przelicznik = 0.3;					// przelicznik: 
	                                            //		stopy na metry 
	
	std::cout << "Podaj wysokosc w stopach: "; 
	std::cin >> stopy;								// przyjecie danej 
	                                                //		z klawiatury 
	
	metry = stopy * przelicznik;			// wlasciwe przeliczenie 
	
	std::cout << "\n"; 		//to samo, co std::cout << std::endl;
	
	// -----wypisanie wynikow ---------
	std::cout << stopy << " stop - to jest: " 
		<< metry << " metrow\n"; 
}
//=======================================================



/************************************************************
Uwaga: MSVC 6.0 nieslusznie ostrzega o nieobecnosci instrukcji return. 
Zignorowac!



************************************************************/
