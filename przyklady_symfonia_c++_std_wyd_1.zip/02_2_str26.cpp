//***************************************************
// Program z paragrafu  2.2 (str 26)
//***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
//***************************************************
int main()
{
  int wys, punkty_karne;      	// definicja dw�ch zmiennych
   								// typu int. Obie s� tego samego typu wi�c
  								// wystarczy przecinek odzielaj�cy nazwy

  std::cout << "Na jakiej wysokosci lecimy ? [w metrach]: ";
  std::cin >> wys;

  // ----------- rozwa�amy sytuacj� ------------------------
  if(wys < 500)
  {
    std::cout << "\n" << wys << " metrow to za nisko !\n";
    punkty_karne = 1;
  }
  else
  {
    std::cout << "\nNa wysokosci " << wys
              << " metrow jestes juz bezpieczny \n";
    punkty_karne = 0;
  }

   // -------------- ocena Twoich wynik�w ----------------
   std::cout << "Masz " << punkty_karne
             << " punktow karnych \n";
   if(punkty_karne)std::cout << "Popraw sie !";
 }



/************************************************************
Uwaga: w ksi��ce, w wyd. pierwszym brak�o std:: przed cin
Zatem powinno byc tak jak tutaj
  std::cin >> wys;


************************************************************/
