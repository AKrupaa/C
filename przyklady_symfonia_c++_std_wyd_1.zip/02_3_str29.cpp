//***************************************************
// Program z paragrafu  2.3 (str 29)
//***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0




#include <iostream> 
int main() 
{ 
	int ile; 
 
	std::cout << "Ile gwiazdek ma miec kapitan ? : "; 
	std::cin >> ile; 
 
	std::cout << "\n No to narysujmy wszystkie " 
					<< ile << " : "; 
 
	// p�tla while rysuj�ca gwiazdki 
	while(ile) 
	{ 
		std::cout << "*"; 
		ile = ile - 1; 
	} 
	// na dow�d, �e mia� prawo przerwa� p�tl� 
	std::cout << "\n Teraz zmienna ile ma wartosc " << ile; 
 }




/************************************************************
Uwaga: MSVC 6.0 nieslusznie ostrzega o nieobecnosci instrukcji return. 
Zignorowac!


************************************************************/
