//***************************************************
// Program z paragrafu  2.4 (str 30)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream> 
int main() 
{ 
	char litera; 
	do { 
		std::cout << "Napisz jakas litere: "; 
		std::cin >> litera; 
		std::cout << "\n Napisales: " << litera << " \n"; 
	}while(litera != 'K'); 										// `1
 
	std::cout << "\n Skoro Napisales K to konczymy !"; 
}


/************************************************************
Uwaga: MSVC 6.0 nieslusznie ostrzega o nieobecnosci instrukcji return. 
Zignorowac!


************************************************************/
