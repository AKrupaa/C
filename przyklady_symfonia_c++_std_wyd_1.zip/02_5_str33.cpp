//***************************************************
// Program z paragrafu  2.5 (str 33)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



#include <iostream> 
int main() 
{ 
	std::cout << "Stewardzie, ilu leci pasazer�w ? "; 

	int	ile;						// liczba pasa�er�w 
	std::cin >> ile; 

 	int i;							// licznik obieg�w p�tli	`1
	for(i = 1 ; i <= ile ; i = i + 1) 		    	// `2
	{ 
		std::cout 	<< "Pasazer nr " << i 
					<< " prosze zapiac pasy ! \n"; 
	}
 
	std::cout << "Skoro wszyscy juz zapieli, to ladujemy. "; 
}




/************************************************************

Uwaga: MSVC 6.0 nieslusznie ostrzega o nieobecnosci instrukcji return. 
Zignorowac!


************************************************************/
