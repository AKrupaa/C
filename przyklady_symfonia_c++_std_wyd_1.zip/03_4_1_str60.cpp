//***************************************************
// Program z paragrafu  3.4.1 (str 60)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



#include <iostream> 
int main() 
{ 
int i 	;							// definicja obiektu 
int k, n, m, j; 
 
	i = 5; 
	k = i + 010;						// czyli:  i + 8 
 
	std::cout << "k= " << k << std::endl; 
 
	m = 100; 
	n = 0x100; 
	j = 0100; 
 
	std::cout << "m+n+j= " << (m+n+j) << "\n"; 
 
	std::cout 	<< "Wypisujemy: "	
					<< 0x22 
					<< " " << 022 
					<< " " << 22 << "\n"; 
}



/************************************************************

Uwaga: MSVC 6.0 nies�usznie ostrzega o nieobecno�ci instrukcji return. 
Zignorowa�!


************************************************************/
