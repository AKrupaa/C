//***************************************************
// Program z paragrafu  3.7.5 (str 76)
//***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>  		// tu s� deklaracje nazw z biblioteki iostream
using namespace std;		// `1
int main() 
{ 
	cout << "Witamy na pokladzie"; 		// <- tu u�ywamy nazwy cout 2
}
/************************************************************
Uwaga: MSVC 6.0 nies�usznie ostrzega o nieobecno�ci instrukcji return. 
Zignorowa�!
************************************************************/

  
