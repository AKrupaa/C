//***************************************************
// Program z paragrafu  3.7.5b (str 77)
//***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>  	
using std::cout;		// 1
using std::cin;			// 2
//*********************************************************
int main() 
{ 
	cout << "Ilu mamy pasazerow?:"; 	// <-- tu u�ywamy nazwy cout 	3
	int liczba_pasazerow;
	cin >> liczba_pasazerow;	 			// <--tu u�ywamy nazwy cin 		4
}


/************************************************************
Uwaga: MSVC 6.0 nies�usznie ostrzega o nieobecno�ci instrukcji return. 
Zignorowa�!
************************************************************/

  
