//***************************************************
// Program z paragrafu  3.8 (str 79)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

int k = 33 ;          //  zmienna globalna (obiekt typu  int)
/*******************************************************/
int main()
{
     cout << "Jestem w main , k =" << k << "\n" ;
     {
          int k = 10 ;                    // zmienna lokalna
          cout << "po lokalnej definicji k ="
               <<     k                                        //
               << "\nale  obiekt globalny  k ="
               << ::k   ;                                   //
     }
     cout << "\nPoza blokiem k =" << k << endl ;

 }


/************************************************************
Uwaga: MSVC 6.0 nies�usznie ostrzega o nieobecno�ci instrukcji return. 
Zignorowa�!


************************************************************/
