//***************************************************
// Program z paragrafu  4.1.1 (str 96)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

int main()
{
int i ;
     for(i = 0 ; i < 64 ; i = i + 1)
     {
          if( i % 8)               //
          {                         //
               cout << "\t" ;       // wypis tabulatora
          }
          else
          {                         //
               cout << "\n" ;            // przejscie do nowej linii
          }
          cout << i ;               //
     }

 }


/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;
------------------------------------------------------
int main()

************************************************************/
