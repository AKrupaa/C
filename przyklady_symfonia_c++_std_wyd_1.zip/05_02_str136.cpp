//***************************************************
// Program z paragrafu  5.2 (str 136)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std; 

long potega(int stopien, long liczba); 
//************************************************************ 
int main() 
{ 
	int pocz, koniec; 
 
	cout << "Program na obliczanie poteg liczb"
			<< "calkowitych\n" 
			<< "z zadanego przedzialu \n" 
			<< "Podaj poczatek przedzialu: "; 
	cin >> pocz; 
 
	cout << "\nPodaj koniec przedzialu: "; 
	cin >> koniec; 
 
	// p�tla drukuj�ca wyniki z danego przedzia�u 
	for(int i = pocz ; i <= koniec ; i++) 
	{ 
		cout << i 
				<< " do kwadratu = " 
				<< potega(2, i)		 					// <-wywo�anie funkcji
				<< " a do szescianu = " 
				<< potega(3, i) 						// <-wywo�anie funkcji
				<< endl; 
	} 
} 
//*************************************************************
long potega(int stopien, long liczba) 
{ 
	long wynik = liczba; 
	for(int i = 1 ; i < stopien ; i++) 
	{ 
		wynik = wynik * liczba; 
		// zwi�lej mo�na zapisa� to samo jako:  wynik *= liczba; 
	} 
	return wynik; 													// `1
} 
//*************************************************************




/************************************************************



************************************************************/
