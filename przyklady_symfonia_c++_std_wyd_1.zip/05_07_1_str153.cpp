//***************************************************
// Program z paragrafu  5.7.1  str 153
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

void funkcja(int a = 2, int  = 6);					// 
//-----------------
int kwadrat(int x) { return x * x; }  			// 
int globalny1 = 32 ; 									// 
//*************************************************************
int main()
{
	funkcja(); 															// 
	
	{      // � otwarcie lokalnego zakresu  �
		cout << "--- Jestesmy w zakresie lokalnym\n";
		
		// wywo�ujemy jeszcze "po staremu"
		funkcja();                 								//  
		
		int lokalny1 = 2 ;                  					// 
		
		// void funkcja(int a = 3, int b);			//<- b��d  
		// void funkcja(int a, int b = lokalny1);	//<- b��d  
		
		void funkcja(int a, int  b = 8);						//  
		
		// od tej pory "po staremu" wywo�a� ju� nie mo�na
		//funkcja();											// <- b��d ! 	 
		
		funkcja(7);	   											// 
		
		globalny1 = 4 + lokalny1;
		
		// argumentem mo�e by� skomplikowane wyra�enie...
		void funkcja(int a =kwadrat(globalny1), int);		// 
		
		funkcja(); 													// 
		
	}  									// 
	cout << "---Jestesmy poza zakresem lokalnym\n";
	
	funkcja();   														//
}
//************************************************************
void funkcja(int a, int b)
{
	cout << "Naprawde nastapilo wywolanie:  funkcja(" 
		<< a << ", " << b << ");" << endl;
}
//************************************************************



/************************************************************

  
************************************************************/