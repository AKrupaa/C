//***************************************************
// Program z paragrafu  5.9 (str 160)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



#include <iostream>
using namespace std ;

float                                                  //
     poczatek_x,           // poczatek ukladu wsp�lrzednych
     poczatek_y ,
     skala_x = 1 ,          // skale: pozioma i pionowa
     skala_y = 1 ;
/*******************************************************/
inline float  wspx(float wspolrzedna)               //
{
     return( (wspolrzedna -  poczatek_x) * skala_x) ;
}
/******************************************************/
inline float  wspy(float wspolrzedna)            //
{
     return( (wspolrzedna -  poczatek_y) * skala_y) ;
}
/******************************************************/
int main()
{
float      x1 = 100,           // przykladowy punkt
          y1 = 100 ;

     cout << "Mamy w punkt o wspolrzednych \n" ;
     cout << " x = " << wspx(x1)                    //
          << " y = " << wspy(y1) << endl ;          //

     // zmieniamy poczatek ukladu wsp�lrzednych
     poczatek_x = 20 ;
     poczatek_y = -500 ;

     cout << "Gdy przesuniemy uklad wspolrzednych tak, \n"
          << "ze poczatek znajdzie sie w punkcie \n"
          << poczatek_x << ", " << poczatek_y
          << "\nto nowe wspolrzedne punktu \n"
          << "w takim ukladzie sa : "
          << " x = " << wspx(x1)                     //
          << " y = " << wspy(y1) << endl ;          //

     // zageszczamy skale na osi poziomej
     skala_x = 0.5 ;
     cout << "Gdy dodatkowo zmienimy skale pozioma tak, "
          << "ze skala_x = " <<     skala_x
          << "\nto ten sam punkt ma teraz wspolrzedne : \n"
          << " x = " << wspx(x1)                     //
          << " y = " << wspy(y1) << endl ;          //


}



/************************************************************


************************************************************/
