 //***************************************************
// Program z paragrafu  5.13 (str 176)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

//*************************************************************
#include <iostream>
using namespace std ;

int  sumator(int jeszcze_krokow, int suma_dotychczas); 	//  
void dwojkowo(int liczba);						  				//  
void schodki(int ile, char znak);
//*************************************************************
int  main()
{
	cout << "Ile pierwszych liczb naturalnych "
				"chcesz posumowac?: ";
	int n = 0 ;
	cin >> n;              									//  

	cout << "\nSuma pierwszych " << n 
		<< " liczb naturalnych to = " 
		<< sumator(n, 0)                				//  
		<< endl;
	//----------------------------------------------------------
	// zupelnie inny przyk�ad funkcji rekurencyjnej
	//----------------------------------------------------------
	int liczba = 241 ;

	cout << "\n" << liczba << " to dwojkowo " ;
	dwojkowo(liczba);                    			//  
	cout << endl ;
	liczba = 30942;
	cout << "\n" << liczba << " to dwojkowo " ;
	dwojkowo(liczba);                    
	cout << endl ;
	return 0;
}
//*************************************************************
int sumator(int jeszcze_krokow, int suma_dotychczas)  		//  
{
	int rezultat = 0 ;													//  
	
	static int krok_rekurencji ;									//  
	krok_rekurencji++ ;												//  
	
	int to_pietro_nr = krok_rekurencji ;        				//  
	schodki(to_pietro_nr, '>');              			// 

	cout << suma_dotychczas << "+ " << to_pietro_nr 
			<< " = " 
			<< (suma_dotychczas + to_pietro_nr) 
			<< endl;
	// w�a�ciwa operacja sumowania
	suma_dotychczas += to_pietro_nr;         			// 

	// warunek zatrzymuj�cy rekurencj� ++++++++++++
	if(jeszcze_krokow > 0)                  			// 
	{
	   // kontynujemy wywo�ania rekurencyjne
	 	rezultat = 
		   sumator(jeszcze_krokow -1, suma_dotychczas);		//
	}
	else 
	{
	   // zatrzymujemy
	   cout << "........to ostatni krok, wracamy ......" 
	 	   	<< endl;
	   rezultat = suma_dotychczas;            			//
	}
	//++++++++++++++++++++++++++++++++++++	

	schodki(to_pietro_nr, '<');								//
	cout << endl;
	krok_rekurencji-- ;                  				//
	return rezultat ;             							//
}
//************************************************************
void dwojkowo(int liczba)     								//
{
	int reszta = liczba % 2 ;      							//
	if(liczba > 1)   					// warunek zatrzymuj�cy 	
	{
		dwojkowo(liczba / 2) ;   	// wywo�anie rekurencyjne	
	}
	cout << reszta ;  												//
	return ;
}
//*************************************************************
void schodki(int ile, char znak)  							//
{
	cout << ile << " pietro: " ;
	for(int m = 0 ; m < ile ; m++)        
	{
		cout << znak << " " ;
	}
	cout << " " ;
}





/************************************************************


************************************************************/
