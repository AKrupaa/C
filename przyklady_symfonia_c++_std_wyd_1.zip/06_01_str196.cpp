//***************************************************
// Program z paragrafu  6.1 (str 196)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0



??=include <iostream>
using namespace std ;

int main()
??<
     int i ;
     char tabl??(30??) ;

     for( i = 0 ; i < 30 ; i ++)
     ??<
          tabl??(i??) = 'a' + i ;
          cout << "zaladowanie do elementu " << i
               << " wartosci " << tabl??(i??) << endl ;
     ??>
     cout << "Poszukiwanie litery k lub m ??/n" ;

     for(i = 0 ; i < 30 ; i ++)
     ??<
          if((tabl??(i??)=='k') ??!??! (tabl??(i??)=='m') )
          ??<
               cout << "Znak " << tabl??(i??)
                    << "jest w elemencie " << i << endl ;
          ??>
     ??>
??>




/************************************************************

************************************************************/
