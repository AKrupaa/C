//***************************************************
// Program z paragrafu  7.1 (str 221)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

int main()
{
	int t[4] ;
	for( int i = 0 ; i < 4 ; i++)
		t[i] = 100 * i ;		  // wpis
	cout << "Wydruk tresci tablicy : \n" ;
	for(int k = 0 ; k < 4 ; k++)
	{
		cout << "Element nr : " << k
			<< " ma wartosc " << t[k] << endl ;
	}
	
	return 0 ;
}

//************************************************************
