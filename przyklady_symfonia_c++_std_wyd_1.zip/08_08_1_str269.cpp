//***************************************************
// Program z paragrafu   8.8.1 (str 269)
//***************************************************
// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



#include <iostream>
using namespace std ;

//****************************************************
int main()
{
                    // definicje dwoch tablic
int ti[6] ;               // jedna int
float tf[6] ;               //druga float
                    //dwa wskazniki
int *wi ;                    // do pokazywania na obiekty int
float *wf ;               // do pokazywania na obiekty float

     wi = &ti[0] ;               // inaczej wi = ti ;
     wf = &tf[0] ;               // inaczej wf = tf ;

     cout << "Oto jak przy inkrementacji wskaznikow\n "
          << "zmieniaja sie ukryte w nich adresy :\n" ;
     for(int i = 0 ; i < 6 ; i++, wi++, wf++)           //
     {
          cout << "i= "<< i
               << ") wi = "
               << reinterpret_cast<unsigned int>(wi)                    //
               << ",  wf = "
               << reinterpret_cast<unsigned int>(wf) << endl ;          //
     }

}



/************************************************************

!!! ISO !!!

Nowy standrard do zamiany wska�nika na liczb� int zaleca u�ywa�
operatora rzutowania renterpret_cast
Zatem mamy:
...
 << reinterpret_cast<unsigned int>(wi)                    //
 << ",  wf = "
 << reinterpret_cast<unsigned int>(wf) << endl ;    
************************************************************/
