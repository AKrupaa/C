//***************************************************
// Program z paragrafu   8.8.2 (str 272)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 

#include <iostream>
using namespace std ;

//****************************************************
int main()
{
int *wi ;
double *wd ;
int tabint[10] = { 0,1,2,3,4,5,6,7,8,9 };               // `1
double tabdbl[10] ;                                        // `2
               // ustawienie wskaznika
     wd = &tabdbl[0] ;                                   // `3

               // zaladowanie tablicy double wartosciami poczatkow.

     for(int i = 0 ; i < 10 ; i++)
     {
          *(wd++)  = i / 10.0 ;             // tablica double `4

     }

     cout << "Tresc tablic na poczatku\n" ;

     wi = tabint;
     wd = tabdbl ;
     for(int k = 0 ; k < 10 ; k++)				// `5
     {
          cout << k << ") \t" << *wi << "\t\t\t\t"
               << *wd << endl ;                         
          wi ++ ;                                        // `6
          wd ++ ;							// `7
     }

     // nowe ustawienie wskaznik�w

     wi = &tabint[5] ;                                   // `8
     wd = tabdbl + 2 ;           // czyli wd = &tabdbl[2];  `9

     // wpisanie do tablic  kilku nowych wartosci
     for(int m = 0 ; m < 4 ; m++){
          *(wi++) = -222 ;                              // `10
          *(wd++) = -777.5 ;
     }

     cout << "Tresc tablic po wstawieniu nowych wartosci\n";
     wi = tabint ;
     wd = tabdbl ;
     for(int p = 0 ; p < 10 ; p++)
	 {
          cout << "tabint[" << i << "] =  "
               << *(wi++)
               << "   \t\ttabdbl[" << p << "] =  "
               << *(wd++)
               << endl ;
     }

}




 