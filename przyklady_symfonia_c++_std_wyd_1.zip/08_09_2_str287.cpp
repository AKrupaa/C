//***************************************************
// Program z paragrafu   8.9.2 (str 287)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

/*******************************************************/
void funkcja_wska(int *wsk, int rozmiar) ;
void funkcja_tabl(int tab[], int rozmiar) ;
void funkcja_wsk2(int *wsk, int rozmiar) ;
/*******************************************************/
int main()
{
	int tafla[4] = { 5,10,15,20 } ;
	funkcja_tabl(tafla, 4);         //
	
	funkcja_wska(tafla, 4);         //
	funkcja_wsk2(tafla, 4);         //
	
}
/*******************************************************/
void funkcja_tabl(int tab[], int rozmiar)                //
{
	cout << "\nWewnatrz funkcji funkcja_tabl \n" ;
	for (int i = 0 ; i < rozmiar ; i++)
		cout << tab[i] << "\t" ;
}
/*******************************************************/
void funkcja_wska(int *wsk, int rozmiar)               //
{
	cout << "\nWewnatrz funkcji funkcja_wska \n" ;
	for (int i = 0 ; i < rozmiar ; i++)
		cout << *(wsk++) << "\t" ;                    //
}
/*******************************************************/
void funkcja_wsk2(int *wsk, int rozmiar)
{
	cout << "\nWewnatrz funkcji funkcja_wsk2 \n" ;
	for (int i = 0 ; i < rozmiar ; i++)
		cout << wsk[i] << "\t" ;
}
//************************************************************

