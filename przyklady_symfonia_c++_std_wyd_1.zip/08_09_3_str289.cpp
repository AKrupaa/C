//***************************************************
// Program z paragrafu   8.9.3 (str  289)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

// deklaracje funkcji
void pokazywacz(const int *wsk, int ile);
void zmieniacz(int *wsk, int ile) ;

/*******************************************************/
int main()
{
int tablica[4] = { 110,120,130,140} ;

     pokazywacz(tablica, 4);                              //
     zmieniacz(tablica, 4);
     pokazywacz(tablica, 4);
     cout << "Dla potwierdzenia tablica[3] = "
          << tablica[3] ;

}
/******************************************************/
void pokazywacz(const int *wsk, int ile)               //
{
     cout << "Dziala pokazywacz " << endl ;

     for(int i = 0 ; i < ile ;  i ++, wsk++)
     {
          // *wsk += 22 ;                    // blad !
          cout << "element nr "<< i << " ma wartosc "
               << *wsk << endl;                         //
     }
}
/******************************************************/
void zmieniacz(int *wsk, int ile)                    //
{
     cout << "Dziala zmieniacz " << endl ;

     for(int i = 0 ; i < ile ;  i ++, wsk++)
     {
          *wsk += 500 ;                    // wolno nam !
          cout << "element nr " << i << " ma wartosc "
               << *wsk << endl;
     }
}
//************************************************************
