//***************************************************
// Program z paragrafu   8.11.1 (str 295)
//***************************************************
// Sprawdzony na Linuksie,   kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 

#include <iostream>
using namespace std ;

char * producent(void) ;                              //
/******************************************************/
int main()
{
char *w1, *w2, *w3, *w4 ;          // definicje wskaznikow


     // tworzenie obiektow
     w1 = producent();                                   //
     w2 = producent();
     w3 = producent();
     w4 = producent();

     *w1 = 'H' ;                                       //
     *w2 = 'M' ;
     *w3 = 'I' ;

     cout <<"oto 3 znaki :" << *w1 << *w2 << *w3
          << "\noraz smiec w czwartym :" << *w4       //
          << endl ;

     delete w1 ;        // kasowanie obiektow

     delete w2 ;
     delete w3 ;

     // *w1 = 'F' ;          //  bylaby tragedia, bo obiekt
                         //  juz nie istnieje !!!

}
/*******************************************************/
char * producent(void)                                    //
{
char *w ;
     cout << "Wlasnie produkuje obiekt \n";
     w = new char ;                                   //
     return w ;
}
//********************************************************
