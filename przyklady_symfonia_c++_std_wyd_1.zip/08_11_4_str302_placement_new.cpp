//***************************************************
// Program z paragrafu   8.11.4  (str 302)
//***************************************************

// Sprawdzony na Linuksie,   kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0 ALE:
 

#include <iostream>
using namespace std ;
#include <new>                             // `1
/******************************************************/
int main()
{

	// Wstepna rezerwacja du�ego obszaru pami�ci
	// (czyli kupujemy grunt na osiedle domow)  
	int *osiedle = new int[5000] ;  // `2
	// zerowanie zdobytego wlasnie obszaru
	for(int i = 0 ; i < 5000 ; i++) osiedle[i] = 1; // `3

	// Teraz na tym terenie mo�emy tworzyc obiekty

	// umieszczenie nowego obiektu =======
	void *gdzie =&osiedle[100];      // `4
	int * wskint = new (gdzie) int;	// `5
	
	//--- praca z tym obiektem ----
	*wskint = 222 ;								// `6
	cout << "*wskint = " << (*wskint) << endl;

	//===============================================
	gdzie =&osiedle[102];
	int * wTabi = new (gdzie) int[3];   // `7
	
	//--- praca z tym obiektem ----
	for(int m = 0 ; m < 3 ; m++) 
	{
		wTabi[m] = 1000+ m ;
		cout << "wTabi[" << m << "] = " 
			<< wTabi[m] << "  ";
	}
	cout << endl;

	//================================================
	gdzie =&osiedle[106];
	double * wTabd = new (gdzie) double[3];    // `8
	
	//--- praca z tym obiektem ----
	for(int n = 0 ; n < 3 ; n++)
	{
			wTabd[n] = 1 + (0.1 * n) ;
			cout << "wTabd[" << n << "] = " 
					<< wTabd[n] << "  ";
	}
	cout << endl;

	// w miejscu o adresie podanym liczbowo ===========

	cout << "Napisz jakis adres pomiedzy: "        
		<< reinterpret_cast<int>(&osiedle[112])   //`9
		<< " - "
		<< reinterpret_cast<int>(&osiedle[116])
		<< "\na ja tam zbuduje ci obiekt : " ;	
	
	int adres_pocz = reinterpret_cast<int>(&osiedle[113]);   

	int adres = adres_pocz +1 ;
	// cin >> adres ;
	gdzie = reinterpret_cast<void *>(adres) ; // `10
	int * wskA = new (gdzie) int;       // `11
	
	//--- praca z tym obiektem ----
	*wskA = 114 ;
	cout << "Wartosc = " << (*wskA) << endl;


	//======================================
	cout << "Zobaczmy na te dzialke \n";    // `12
	for(int k = 99 ; k < 116 ; k++) 
		cout << "[" << k << "]=" << osiedle[k] << endl ;


	delete [] osiedle ;        

}
/******************************************************/



