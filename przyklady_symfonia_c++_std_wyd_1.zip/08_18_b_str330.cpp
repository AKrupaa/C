//***************************************************
// Program z paragrafu   8.18 b)  (str 330)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;



char * strcpy(char *cel, const char *zrodlo) ;
/******************************************************/
int main()
{
	char poziom[] = { "Poziom szumu w normie" } ;
	char komunikat[80] ;
	
	strcpy(komunikat,  poziom) ;                    //
	cout << poziom  << endl ;
	cout << komunikat  << endl ;
	
}
/******************************************************/
char * strcpy(char *cel, const char *zrodlo)             //
{
	char *poczatek = cel ;                           //
	
	while(  (*(cel++) = *(zrodlo++))  );             //
	return poczatek ;                              //
}
/******************************************************/




