//***************************************************
// Program z paragrafu   8.18 c)  (str 335)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

char* strcat(char *cel, const char *zrodlo) ;
/******************************************************/
int main()
{
	char co[] = { "urzadzen sterowych" } ;
	char komunikat[80] = { "Alarm :" };
	
	strcat(komunikat,  co) ;
	cout << "po dopisaniu = "
		<< komunikat  << endl ;                        //
	cout << (strcat(komunikat, ", o godz 17:12") ) ;//
	
	
}
/******************************************************/
char * strcat(char *cel, const char *zrodlo)               //
{
	char *poczatek = cel ;
	
	// przesuniecie napisu na koniec stringu
	while(*(cel++) );                                  //
	
	// teraz pokazuje o 1 znak za NULL
	cel--;                                             //
	
	// to juz bralismy przy strcpy
	while(  (*(cel++) = *(zrodlo++))  );                    //
	
	return poczatek ;
}
/*******************************************************/


