//***************************************************
// Program z paragrafu  8.19.3 (str 358)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std;

#include <cstdlib>			// dla: exit
#include <cmath> 			// dla: sinus

void kurs();
void wiatraczek();
void wahadlo();
//************************************************************
void zwloka_czasowa(int ile)
{
	for(int i = 0 ; i < ile *1000 ; i++);
}
/*************************************************************/
int main()
{
	void (*twf[3])() = {	wahadlo,
		wiatraczek,
		kurs};   								//  
	int co;
	while(1)
	{
		cout 	<< "---------------Menu -----------------\n"
			<< "\t0 - wahadlo\n\t1 - wiatraczek \n\t"
			<< "2 - kurs\n\t9 - koniec programu\n\n"
			<< "Podaj numer zadanej akcji: ";
		cin >> co; 														//  
		
		switch(co)
		{
		case 0:
		case 1:
		case 2:
			(*twf[co])(); 									//  
			//  twf[co]();  		// <�� to samo pro�ciej
			break;
			
		case 9: 						// koniec
			exit(1);
			
		default:
			break;
		}
	}
}
/*************************************************************/
void kurs()																//  
{
	for(int i = 0 ; i < 100 ; i++)
	{
		cout 	<< "kurs " 
			<< (232 + (i % 4))
			<< "...\r";
		zwloka_czasowa(50000);
	}
	cout <<"\nPokazywalem kurs...\n";
}
/*************************************************************/
void wiatraczek()  													//  
{
	char symbol[] = { '|', '/', '-', '\\' };
	
	for(int i = 0 ; i < 100 ; i++)
	{
		cout << "        " << symbol[i % 4] << "\r";
		zwloka_czasowa(10000);
	}
	cout <<"\nWiatraczek sie pokrecil...\n";
}
/*************************************************************/
void wahadlo() 															//  
{
	cout << '\n';
	
	char wzorek[25]; 
	for(int i = 0 ; i < 500 ; i++)
	{
		// przygotowanie tablicy spacji
		for(int k = 0 ; k < 25 ; k++) wzorek[k] = ' ';
		wzorek[24] = 0;  // ko�czacy C-string znak null (ma on kod ASCII �> 0)
		
		// wstawienie w jeden z element�w znaczka '*'
		int pozycja = 12 * sin(i /20.0) + 12;
		wzorek[pozycja] = '*';
		
		// wydruk na ekran, a potem powr�t karetki do pocz�tku linijki
		cout << wzorek << '\r';
		zwloka_czasowa(5000);
	}
	cout <<"\n";
}


