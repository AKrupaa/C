//***************************************************
// Program z paragrafu   10.14 (str 458)
//***************************************************

// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;

#include <cstring>               // bo uzyjemy: strcpy()

///////////////////////////////////////////////////////
class numer {
     int     liczba ;
     char nazwa[40] ;
public:
     // --------funkcje skladowe
     // konstruktor -tylko deklaracja
     numer(int k, const char *opis) ;              //

     // dalsze funkcje skladowe
     void     schowaj(int k)
     {
          liczba =k  ;
          melduj() ;                               //
     }
     // -----
     int     zwracaj()      { return liczba ; }
     // ----
     void melduj()                                 //
     {
          cout << nazwa << liczba << endl ;
     }
} ;
////////  koniec definicji klasy ///////////////////////
numer::numer(int l, const char *opis)              //
{
    liczba = l ;
	strcpy(nazwa, (opis ? opis : ""));
}
/******************************************************/
int main()
{
numer  samolot(1200, "Biezaca wysokosc ") ;        //
numer  atmosfera(920, "Cisnienie atmosferyczne "),  //

       kurs(63, "Kierunek lotu ");

       // wstepny raport

       samolot.melduj() ;
       kurs.melduj();                          //
       atmosfera.melduj();

       cout << "\nKorekta lotu -----\n" ;
       samolot.schowaj(1201);                  //

       // zmiana kursu o 3 stopnie
       kurs.schowaj( kurs.zwracaj() + 3) ;     //

       //cisnienie spada
       atmosfera.schowaj(919) ;

}


