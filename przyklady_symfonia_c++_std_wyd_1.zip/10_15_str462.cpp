//***************************************************
// Program z paragrafu   10.15 (str 462)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;

#include <cstring>               // bo uzyjemy: strcpy()

/////////////////////////////////////////////////////////
class gadula {
     int      licz ;
     char tekst[40] ;
public :

     // konstruktor
     gadula(int k, const char *opis) ;

     // destruktor - deklaracja
     ~gadula(void) ;                                   //

     // inne funkcje skladowe
     int zwracaj() { return licz ; }
     void schowaj(int x) { licz = x ; }
     void coto()
     { cout << tekst << " ma wartosc "<< licz << endl; }
} ;
////////////////////////////////////////////////////////
gadula::gadula(int k, const char *opis)          // konstruktor
{
     strcpy(tekst, opis? opis : "");
     licz = k ;
     cout << "Konstruuje obiekt " << tekst << endl ;
}
/******************************************************/
gadula::~gadula()                         // destruktor
{
     cout << "Pracuje destruktor (sprzata) "
          << tekst << endl ;
}
/******************************************************/
gadula a(1, "obiekt a (GLOBALNY)");                    //
gadula b(2, "obiekt b (GLOBALNY)");
/******************************************************/
int main()
{
     a.coto() ;
     b.coto() ;                                         //
     {                    // <-- !
          cout << "Poczatek lokalnego zakresu --------\n";
          gadula c(30, "obiekt c (lokalny)");         //
          gadula a(40, "obiekt a (lokalny)"); // zaslania !


          cout << "\nCo teraz mamy :\n" ;
          a.coto() ;                                   //
          b.coto() ;
          c.coto() ;

          cout << "Do zaslonietego obiektu globaln mozna "
                    "sie jednak dostac\n" ;
          ::a.coto() ;                                //
          cout << "Konczy sie lokalny zakres ---------\n";
     }                                                  //
     cout << "Juz jestem poza blokiem \n" ;
     a.coto() ;                                        //
     b.coto() ;
     cout << "Sam uruchamiam destruktor obiektu a\n";
     a.gadula::~gadula() ;                          //
     cout << "Koniec programu !!!!!!!!\n";         //

}
/************************************************************

------------------------------------------------------
Uwaga: To, kiedy dokladnie likwidowane sa obiekty - jest zalezne
od konkretnego kompilatora. To jest jego prywatna sprawa,
wiec kompilujac ten przyklad roznymi kompilatorami
mozesz otrzymywac program wypisujacy teksty destruktora
w nieco innym miejscu (czyli czasie).


************************************************************/
