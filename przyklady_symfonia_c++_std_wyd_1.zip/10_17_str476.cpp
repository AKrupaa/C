//***************************************************
// Program z paragrafu   10.17 (str 476)
//***************************************************


// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;

#include <cstring>

enum tak_czy_nie { nie, tak } ;                         //
////////////////////////////////////////////////////////
class piorko {
     int poz_x, poz_y ;
     static int zezwolenie ;                            //
     char kolor[30] ;

     // funkcje ------------------------------------------------------------
public :
     void jazda(int x , int y)
     {
          cout << "Tu "<< kolor << " piorko : " ;
          if(zezwolenie){                               //
               poz_x = x ;
               poz_y = y ;
               cout << "Jade do punktu ("
               << poz_x  << ", " << poz_y << ")\n" ;
          }
          else
          {
           cout <<
               "     Nie wolno mi jechac !!!!!!!!!!!!! \n" ;
          }
     }
     //--------------------------------------------------


     static void czy_mozna(tak_czy_nie odp)
     {
          zezwolenie = odp ;          // skladnik statyczny
          // poz_x = 5 ;      // blad ! bo skladnik zwykly
     }
     // ---------------------------------------------

     piorko(const char * kol)
     {
		 strcpy(kolor, (kol ? kol : "") );
         poz_x = poz_y = 0 ;
     }
};
/////////////////////////////////////////////////////////
int piorko::zezwolenie ;
/******************************************************/
int main()
{
     piorko::czy_mozna(tak) ;                              //

     piorko czarne("SMOLISTE"), zielone("ZIELONIUTKIE") ;

     czarne.jazda(0, 0) ;
     zielone.jazda(1100, 1100) ;

     // zabraniamy ruchu piorkom
     piorko::czy_mozna(nie) ;

     czarne.jazda(10, 10) ;
     zielone.jazda(1020, 1020) ;

     // zezwalamy w taki sposob
     zielone.czy_mozna(tak);                                //
     czarne.jazda(50, 50) ;
     zielone.jazda(1060, 1060) ;

}

//************************************************************
