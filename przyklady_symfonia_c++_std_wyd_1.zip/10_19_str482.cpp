//***************************************************
// Program z paragrafu   10.19 (str 482)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;


////////////////////////////////////////////////////////
class pozycja {
     int  x ,
          y ;
public :
     pozycja (int a, int b ) {x = a ; y = b ; }
     void wypis (void) const ;                     //
     void przesun(int a, int b);
} ;
/////////////////////////////////////////////////////////
void pozycja::wypis() const                         //
{
     cout << x << ", " << y << endl ;
}
/*******************************************************/
void pozycja::przesun(int a , int b)
{
     x = a;    y = b ;                            //
}
/*******************************************************/
int main()
{
     pozycja      samochod(40, 50),                  //
               pies(30, 80) ;

     const pozycja dom(50, 50) ;                   //

     // zastosowanie funkcji skladowej - const

     samochod.wypis() ;
     pies.wypis() ;                               //
     dom.wypis() ;

     // zastosowanie funkcji nie-const

     samochod.przesun(4,10) ;
     pies.przesun(50, 50) ;
     // dom.przesun(0, 0) ;               // blad  !


}

