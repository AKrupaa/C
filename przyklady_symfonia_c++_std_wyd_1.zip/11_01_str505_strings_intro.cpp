//***************************************************
// Program z paragrafu   11.1 (str 505)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
#include <string>				// `1
using namespace std ;			// `2
void plakat(string s);          // `3
//***********************************************************
int main()
{
	string klub1("Wisla");     // `4   
	string klub2("Unia");
	
	string mias1 = "Krakow";		// `5
	string mias2 = "Tarnow";

	string polaczenie ;			// `6 
	polaczenie = klub1 + klub2 ; // `7
	cout << "Dodanie dwoch stringow=" 
		 << polaczenie << "\n\n";

	string zapowiedz = klub1 + "-" + mias1;   // `8
			
	zapowiedz = zapowiedz + " vs. " ;   // `9
		
	zapowiedz += klub2;  // `10
	zapowiedz += ('-' + mias2);   

	cout << "!!! Zapraszamy na mecz !!!\n" ;
	plakat(zapowiedz);   // `11

	zapowiedz += "   Rezultat meczu " ; //`12

	cout << "\n\nPodaj wynik meczu  ";
	string wynik  ;   // `13
	cin >> wynik ;    // `14

	cout << "\n\nUWAGA: Wczoraj odbyl sie mecz\n" ;
	plakat(zapowiedz + wynik);   // `15


}
//**********************************************************
void plakat(string tresc)  // `16
{
	string gwiazdki(tresc.length() + 6, '*');  // `17
	cout << gwiazdki << '\n' 
		<< gwiazdki << "\r"
		<< "** " << tresc << " **\n"          // `18
		<< gwiazdki << endl; 
}


/************************************************************

************************************************************/
