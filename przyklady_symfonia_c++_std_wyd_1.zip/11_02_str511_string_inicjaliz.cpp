//***************************************************
// Program z paragrafu    11.2 (str. 511)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
#include <iomanip>   //`1

#include <string>				
using namespace std ;

//**********************************************************			
void pokaz(string opis, string wlasciwy)  // `2
{
	cout << "Tresc obiektu " 
		<< setw(15)  // `3
		<< opis 
		<< ": -->" 
		<< wlasciwy 
		<< "<--\n" ;
}
//***********************************************************
int main()
{

	string napisA;  // `4

	string napisB1("Jakis tekst"); 			// `5
	
	char tablica[20] = { "Natenczas Wojski" };	
	string napisB2(tablica); 				// `6 

	string wiadomosc(&tablica[5]);			// `7

	string ostrzezenie("Awaria studni", 8);  // `8
	
	string gwiazdki(25, '*');	// `9
	
	string inny = "ABCDEFGH";
	string nowy(inny, 4, 2);  // `10

	char tab[] = {"0123456789ABCDEF"};
	string n1(&tab[3], &tab[9]); // `11
	
	string lufa("Celownik zostal ustawiony") ;
	string n2(&lufa[5], &lufa[18]);   // `12
	
	//====== Dla sprawdzenia ===========
	pokaz("napisA", napisA);
	pokaz("napisB1", napisB1);
	pokaz("napisB2", napisB2);
	pokaz("wiadomosc", wiadomosc);
	pokaz("ostrzezenie", ostrzezenie);
	pokaz("gwiazdki", gwiazdki);
	pokaz("nowy", nowy) ;
	pokaz("n1", n1);
	pokaz("n2", n2);

}
//**********************************************************

