//***************************************************
// Program z paragrafu 11.7 str 565
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
#include <string>
using namespace std;

#include <algorithm>   			// <- dla transform
#include <cctype>      			// <- dla tolower

// deklaracje funkcji 
string zrob_male_p(string dany);
string zrob_male_a(string dany);

//**********************************************************
int main()
{

	string h1("Hector Villa Lobos");
	string h2("hector villa lobos");

	cout 	<< "Dwa stringi \n[" << h1 
			<< "] oraz [" << h2 << "]\n";

	cout 	<< "Przy porownaniu wrazliwym na wielkosc liter..." 
			<< endl;

	if(h1 != h2)   									//  
	{
		cout << " -> sa rozne " << endl;
	}

	cout 	<< "Przy porownaniu NIEwrazliwym na wielkosc liter..."
			<< endl;
	
	if(zrob_male_p(h1) == zrob_male_a(h2))  			//  
	{
		cout << " - sa identyczne" << endl;
	}
}
//*************************************************************
string zrob_male_p(string dany)  							//  
{
	for(int i = 0 ; i < dany.length() ; i++)
	{
		dany[i] = tolower(dany[i]);  // przypisanie "w ciemno" 			//  
	}
	return dany;
}
//*************************************************************
// funkcja dla wtajemniczonych
string zrob_male_a(string dany) 							//  
{
	transform(	dany.begin(), dany.end(), 
					dany.begin(), tolower); 					//  
	return dany;
}


