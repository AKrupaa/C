//***************************************************
// Program z paragrafu   11.22 (str 579)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <string>
#include <iostream>
using namespace std;
//-------------------------------------
int main()
{
		string miasto("Sajgon");
		cout << "Podaj nowa nazwe miasta "
				<< miasto << ": "<< endl;
		getline(cin, miasto);
		cout << "Teraz jest: [" << miasto << "]" << endl;
}

 
