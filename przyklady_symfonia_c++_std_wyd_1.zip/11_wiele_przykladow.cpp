//***************************************************
// Program z paragrafu 11.7 str 565
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
#include <iomanip>   //`1

#include <string>
#include <stdexcept>  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

using namespace std ;

#include <algorithm>
#include <cctype>

// deklaracje roznych funkcji
string zrob_male_p(string dany);
string zrob_male_a(string dany);

//**********************************************************
void pokaz(string opis, string wlasciwy)  // `2
{
	cout << "Tresc obiektu "
		<< setw(15)  // `3
		<< opis
		<< ": -->"
		<< wlasciwy
		<< "<--\n" ;
}
//**********************************************************
void informacja(string opis)
{
	cout << "\n######################\nPrzyklad na " 
		<< opis 
		<< "\n######################" << endl;
}
//***********************************************************
int main()
{
	
	
	informacja("f. size i length");
	string stri("Jan Kot");
	
	string spiewak("Jan Kiepura");  
	
	
	cout << " nazwisko.size() = " <<spiewak.size() << endl ;
	cout << "nazwisko.length() = " << spiewak.length() << endl;
	cout << endl;
	
	char tab[] = "Jan Kiepura";
	cout << sizeof(tab);
	
	informacja("f. empty, max_size");
	string nic;
	if(nic.empty())
	{
		cout << "nic jest na razie pusty" << endl;
	};
	
	cout << "Max = " << nic.max_size() << endl;
	
	
	
	informacja("f. reserve, capacity");
	string poemat ;
	
	
	poemat.reserve(100);
	string::size_type  poprz_poj = poemat.capacity();
	
	for(int k = 1 ; k < 500 ; k++)
	{
		poemat += 'A';
		string::size_type poj = poemat.capacity() ;
		
		if(poj != poprz_poj)
		{
			cout
				<< "Gdy liter =" << k
				<< ", zwiekszylem poj = "
				<< poj
				
				<< ", (+"
				<< (poj  - poprz_poj)
				<< ")" << endl;
			poprz_poj = poj ;
		}
		
	}
	
	
	informacja("f. resize");
	
	string zd("123456789");
	zd.resize(15);
	cout << "zd = >" << zd << "< len =" << zd.length() 
		<< " cap = " << zd.capacity() << endl ;
	zd.resize(6, 'x');
	cout << "zd = >" << zd << "< len =" << zd.length() 
		<< " cap = " << zd.capacity() << endl ;
	
	
	string a("ABC");
	a.resize(7, 'x');
	cout << "string a= >" << a << "< ma dlugosc " << a.length() << endl;
	a.resize(15);
	cout << "string a  >" << a
		<< "< ma dlugosc "
		<< a.length() << endl;
	
	
	for(int n = 0 ; n < a.length() ; n++)
	{
		cout << (int)a[n] << ", " ;
	}
	
	informacja("f. at i operator []");	 
	
	
	string wyd("Kallimach");
	cout << wyd[1] << endl;
	cout << wyd.at(1) << endl;
	
	
	for(int zn = 0 ; zn < a.length() ; zn++)
	{
		cout << wyd[zn] << endl ;
	}
	
	
	for(int i = 0 ; i < 6 ; i++)
	{
		cout << "wyd[" << i << "] --> "
			<< wyd[i]
			<< endl;
	}
	
	wyd[0] = 'B' ;
	wyd.at(5) = 'c' ;
	
	//	wyd[100] = 'B' ;
	//wyd.at(5) = 'c' ;
	
	
	string tabliczka("Palenie Wzbronione");
	cout << "Ktora pozycje stingu "
		<< tabliczka
		<< " chcesz odczytac? :" ;
	string::size_type poz ;
	cin >> poz ;
	
	// sprawdzamy poprawno�
	if(poz >= 0 && poz < tabliczka.length() )
	{
		cout << "Na tej pozycji stoi znak: "
			<< tabliczka.at(poz)
			<< endl;
	}
	else
	{
		cout << "To jest niepoprawna pozycja " << endl;
	}
	
	cout << "Po zamianiach: "
		<< wyd << endl;
	
	
	informacja("rzucanie wyjatku przez funkcje at");
	
	
	string nakaz("Cisza!");
	try{
		
		for(int pozycja = 0 ; pozycja < 16 ; pozycja++)
		{
			
			cout << "Proba odczytania znaku nakaz["
				<< pozycja
				<< "] --> ";
			cout << nakaz.at(pozycja)  << endl;
		}
	}
	catch(out_of_range x)
	{
		
		cout << "\n  Takiej pozycji w stringu nakaz nie ma" << endl;
	}
	
	informacja("f. substr");
	
	string nazwa_pliku("detektor_A12.txt");
	string sam_symbol;
	try
	{
		
		sam_symbol = nazwa_pliku.substr(9, string::npos);
		cout << sam_symbol << endl;
	}
	catch(out_of_range)
	{
		
		cout << "\n  Zle okrelenie substringi" << endl;
	}
	
	//---------------------
	informacja("f. find");
	
	string nazwa("Aby rzucic dyskiem, trzeba wykonac zamach noga "
		"a potem zamach reka");
	
	string::size_type pozycja;
	pozycja =	nazwa.find("zamach");
	
	if(pozycja != string::npos) // znalezione!
	{
		cout << "Terrorystyczne slowo na pozycji " << pozycja << endl;
	}
	else
		cout << "Podejrzanej grupy znakow nie ma " << endl;
	
	
	
	//------------------
	
	//	string::size_type pozycja;
	
	string sentencja("Cala wiedza naszych przodkow miesci sie");
	string slowo = "miedza" ;
	
	
	// jak przesun�sobie pocztek ?
	pozycja =  sentencja.find(slowo.substr(1, 3), 0);
	if(pozycja != string::npos)
	{
		cout << "Znalezione na pozycji " << pozycja
			<< "\n czyli od: "
			<< sentencja.substr(pozycja)
			<< endl;
	}
	
	string zdanie("Wszyscy �pi�");
	
	pozycja = zdanie.find_last_not_of("aoeiou��");
	if(pozycja != string::npos)
	{
		cout << "zdanie: >" << zdanie << "< ma " << zdanie.length()
			<< " znakow\n ostatnia NIE-samogloska jest na pozycji "
			<< pozycja
			<< "\n (jest to litera " << zdanie[pozycja]
			<< ")\n";
	}
	else
	{
		cout << "W tym stingu sa same samogoski" << endl;
	}
	
	informacja("f. erase z iteratorem");
	
	string Grieg("Suita Peer Gynt");
	string::iterator it = Grieg.begin()+ 3  ;  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	//Grieg.erase(&Grieg[3]);
	Grieg.erase(it);
	
	cout << Grieg << endl;
	
	
	informacja("f. insert");
	
	//	string & insert(size_type gdzie_wstawi� const string & co_wstawi�;   `1
	
	string urzadzenie("detektor_energia");
	string segment("1A3");
	
	urzadzenie.insert(8, segment, 1, 2) ;
	cout << urzadzenie << endl;
	
	// string & insert(size_type gdzie_wstawi� const string & co_wstawi� size_type skad_zacz� size_type ile_znak�); `2
	
	
	//string & insert(size_type gdzie_wstawi� const char * co_wstawi�;   `3
	
	string tytul("Pod Zycie Weroniki");
	tytul.insert(3, "wojne");
	cout << tytul << endl;
	
	
	char * wieszcz ="Adam Mickiewicz - tworca Dziad�";
	
	string komunikat("Poeta wychowal sie...");
	
	komunikat.insert(6, wieszcz, 16);
	cout << komunikat << endl;
	
	
	//	string & insert(size_type gdzie_wstawi� const char * co_wstawi� size_type ile_znak�);   `4
	
	string rozmowa("Paryz > Rzym");
	rozmowa.insert(6, 12, '=');    // "Paryz ============> Rzym"
	
	
	
	informacja("f. replace");							   
	
	
	string opis("Obraz uszkodze�DNA");
	string dzialanie("owanie");
	
	opis.replace(5, 10, dzialanie) ;     //
	cout << opis << endl;
	
	
	string moj("abcdefgh");
	string cyfry("0123456789");
	
	moj.replace(3, 2, cyfry, 4, 5) ;   // "abc45678fgh"
	cout << moj << endl;
	
	
	string dzial("Bank ogolny");
	const char * proces = "spermatogeneza" ;
	dzial.replace(5, 5, proces, 5);   // "Bank spermy"
	cout << dzial << endl;
	
	dzial.replace(5, 5, proces + 8 , 3);   // "Bank geny"
	cout << dzial << endl;
	
	
	
	string badanie("Obrazowanie RTG mozgu");
	const char * rezonans = "MRJ";
	
	string::size_type p = badanie.find("RTG");
	if(p != string::npos)
	{
		badanie.replace(p, 3, rezonans);                //  "Obrazowanie MRJ mozgu"
	}
	
	cout << badanie << endl;
	
	
	string inf("Morderca Kuba Rozpruwacz czail sie");
	inf.replace(9, 15, 3, 'x');  // "Morderca xxx czail sie"
	cout << inf << endl;
	
	
	informacja("f. replace iteratorami");
	
	string decyzja("Otworzyc komory prozniowe");
	string zaw("zawory");
	
	string::iterator odtad = decyzja.begin() + 9;
	string::iterator dotad = odtad + 6 ;
	
	decyzja.replace(odtad, dotad, zaw);  // "Otworzyc zawory prozniowe"
	
	cout << decyzja << endl;
	
	
	informacja("f. replace iteratorami c-string");
	
	string adc ("Pomiar nachylenia przemiennika");
	
	string::iterator  tu = adc.begin() + 7;
	string::iterator  tam = tu + 10 ;
	
	adc.replace(tu, tam, "rozdzielczosci");  // "Pomiar rozdzielczosci przemiennika"
	
	cout << adc << endl;
	
	
	string scyntyl("Pomiar trajektorii przelotu");
	
	string::iterator  odt = scyntyl.begin() + 7;
	string::iterator  dot = odt + 11 ;
	
	scyntyl.replace(odt, dot, "czasu martwego", 5);  // "Pomiar czasu przelotu"
	
	cout << scyntyl << endl;
	
	//----------
	string tof("sci21 do sci42");
	
	string::iterator  it1 = tof.begin() + 6;
	string::iterator  it2 = it1 + 2  ;
	
	tof.replace(it1, it2, 10, '>');  // "sci21 >>>>>>>>>> sci42"
	
	cout << tof << endl;
	
	
	//------------
	string ilocz("Iloczyn bramek jednowymiarowych");
	
	string::iterator  itA = ilocz.begin() + 8;
	string::iterator  itB = itA + 6 ;
	
	string zest("zestaw warunkow koniecznych");
	
	string::iterator  itX = zest.begin() + 7;
	string::iterator  itY = itX + 8 ;
	
	ilocz.replace(itA, itB, itX, itY);  // "Iloczyn warunkow jednowymiarowych"
	cout << ilocz << endl;
	
	void biblioteczna(const char * wsk);
	
	string obiekt("nazwa_pliku.ext");
	biblioteczna( obiekt.c_str() );
	
	informacja("f. c_str()");
	
	void otwarcie_pliku(const char * wsk) ;
	
	for(int grupa = 0 ; grupa < 5 ; grupa++)
	{
		for(int segment = 0 ; segment < 3 ; segment++)
		{
			string nazwa_pliku("miniball_");
			nazwa_pliku += char('1' + grupa);
			nazwa_pliku += "_" ;
			nazwa_pliku += char('A' + segment) ;
			nazwa_pliku += ".parametry" ;
			
			otwarcie_pliku(nazwa_pliku.c_str() );
			// teraz czyta z tego pliku
			// ...
		}
	}
	
	
	informacja("f. prownujace alfabetycznie");
	
	//---------------
	string filozof("Kant");
	string ktos("Kartezjusz");
	
	
	cout << "Alfabetycznie nazwisko: "
		<< filozof ;
	
	
	switch(filozof.compare(ktos))
	{
	case -1:
		cout << " stoi przed nazwiskiem " << ktos ;
		break ;
		
	case 0:
		cout << " jest w tym samym miejscu co "  << ktos ;
		break ;
		
	case 1:
		cout << " nastepuje po nazwisku " << ktos  ;
		break ;
	}
	
	cout << endl;
	
	string fizyk("Prof. A. Hrynkiewicz");
	string inny("Motelson");
	
	cout << "W kolejnosci alfabetycznej ma byc:\n";
	if(fizyk.compare(9, string::npos, inny) == -1)
	{
		cout << fizyk << ", " << inny << endl;
	}else{
		cout << inny << ", " << fizyk << endl;
	}
	
	
	string uczonyX("Prof. A. Hrynkiewicz");
	string uczonyY("Prof. M. Curie");
	
	cout << "W kolejnosci alfabetycznej ma byc:\n";
	if(uczonyX.compare(9, string::npos, uczonyY, 9, 100) == -1)
	{
		cout << uczonyX << ", " << uczonyY << endl;
	}else{
		cout << uczonyY << ", " << uczonyX << endl;
	}
	
	string wynalazca("Edison");
	
	int odpowiedz = wynalazca.compare("Szczepanik");
	
	if(odpowiedz == -1)
	{
		cout << wynalazca
			<< " jest alfabetycznie wczesniej" << endl;
	}
	
	
	{
		string urzadzenie("trzy komory DRUTOWE");
		char music[] = "komora JONIZACYJNA" ;
		
		int odp = urzadzenie.compare(12, string::npos, music+7, 200);
		if(odp == -1)
			cout << "Urzadzenie typu: " << urzadzenie
			<< "\n jest alfabetycznie wczesniej niz: "
			<< music << endl;
	}
	
	
	{
		string nnn("abc");
		int odp = nnn.compare("DEF");
		cout << odp << endl;
	}
	
	// ~==#, ~!=#, ~<#, ~>#,  ~<=#, ~>=#.
	{
		string k("Krakow");
		string p("Piwniczna");
		string p2("Piwniczna");
		
		if(k == p)
		{
			cout << "Tresc obiektow k i p jest identyczna\n" ;
		}
		
		if(k != p)
		{
			cout << "Tresc obiektow k i p jest rozna\n" ;
		}
		
		if(k < p)
		{
			cout << k << " stoi alfabetycznie przed " << p << endl;
			
		}
		
		if(k > p)
		{
			cout << k << " stoi alfabetycznie po " << p << endl;
		}
		
		
		if(p <= p2)
		{
			cout << p
				<< " stoi alfabetycznie przed, lub jest rowna "
				<< p2 << endl;
			
		}
		
		if(p >= p2)
		{
			cout << p
				<< " stoi alfabetycznie po, lub jest rowne "
				<< p2 << endl;
		}
		
		
	}
	
	informacja("f. copy, swap");
	
	char tablica[100] = { "habent*sua*fata*libelli"  };
	string przepis("Olejek bezwonny lej przez lejek, ...");
	
	przepis.copy(tablica, 15, 1);
	cout << "Zawartosc obiektu tablica: '" << tablica
		<< "'" << endl;
	
	
	string ofiara("Desdemona");
	string bestia("Otello");
	
	cout << "Przed zamiana ofiara: " << ofiara
		<< ", bestia: " << bestia << endl;
	
	ofiara.swap(bestia);
	cout << "Po zamianie ofiara: " << ofiara
		<< ", bestia: " << bestia << endl;
	
	
	informacja("f. assign");
	
	// przypisanie assign
	string ochotnik ;
	string studentM("Konrad");
	
	ochotnik.assign(studentM);
	
	cout << "Ochotnikiem jest " << ochotnik << endl;
	
	
	string nowy;
	string wers("Gdy ryczy z bolu ranny lew");
	nowy.assign(wers, 17, 5);
	cout << nowy << endl;
	
	string wyswietlacz("200 MeV");
	wyswietlacz.assign("15 MeV na nukleon", 6);
	cout << wyswietlacz << endl;
	
	string rzad("&&&&&&&&");
	rzad.assign(15, '$');
	
	cout << rzad << endl;
	//-------------
	{
		string aktywne("---");
		string wszystkie("mw21, mw22, mw31 mw41, mw42");
		
		string::iterator  it1 = wszystkie.begin() + 12;
		string::iterator  it2 = it1 + 4  ;
		
		aktywne.assign(it1, it2);  // "mw31"
		
		cout << aktywne << endl;
		char zestaw[] = "sci21 sci22 sci41";
		it1 = &zestaw[6];    //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		it2 = it1 + 5;
		aktywne.assign(it1, it2);  // "sci22"
		cout << aktywne << endl;
		
	}
	
	
	
	informacja(" wczytywanie wielowyrazowego tekstu. Uwaga VisualC++ tu zle zadziala!");
	
	
	//------------------
	
	string miasto("Sajgon");
	cout << "Podaj nowa nazwe miasta " 
		<< miasto << ": "<< endl;
	
	
	getline(cin, miasto, 'x');  // <-- na sile dalem tu x, bo pulapka
	cout << "Teraz jest: [" << miasto << "]" << endl;
	
		  cout << "Napsz dowolnie dlugi opis swojego miasta, koniec tekstu oznacz znakiem 'v'"
			  << endl;
		  
		  getline(cin, miasto, 'v');
		  cout << "Oto zawartosc obiektu miasto [" 
			  << miasto 
			  << "]"
			  << endl;
		  
		  
		  
		  informacja(" rozne operacje iteratorami");
		  
		  
		  {
			  string koleda("Gloria in Excelsis Deo");
			  
			  int zacznij = 3;
			  int ile = 12;
			  
			  cout << "W stringu [" << koleda << "]" << "\nzamienie "
				  << ile << " znakow poczawszy od " 
				  << zacznij << endl;
			  
			  string::iterator it;
			  it = koleda.begin() + zacznij;
			  
			  for(int i = 0  ; i < ile ; i++)
			  {
				  *it++ = '.';
			  }
			  
			  cout << "Rezultat: [" << koleda << "]\n";
			  
			  
			  const string Ew_Jan("Na poczatku bylo slowo");
			  
			  string::const_iterator itJan = Ew_Jan.begin();
			  
			  
			  while(itJan != Ew_Jan.end())
			  {
				  cout << '_' << (*itJan++);
			  }
			  
			  itJan--; // zeby sprawdzi� czy to dzia�a
			  
			  
			  {
				  
				  
				  
				  cout << "zamiana na male litery" << endl; 
				  
				  string dziwny("To Jest Taki DzIwNy TeKsT");
				  string maly = dziwny;
				  
				  // zrobione "recznie" 
				  for(int i = 0 ; i < maly.length() ; i++)
				  {
					  maly[i] = tolower(maly[i]);
				  }
				  
				  cout << "maly = [" << maly << "]" << endl; 
				  
				  // zrobimy to samo tzw. "algorytmem" transform
				  maly = dziwny;
				  transform(dziwny.begin(), dziwny.end(), maly.begin(), tolower);
				  
				  cout << "maly = [" << maly << "]" 
					  << "a dziwny = [" << dziwny << "]" << endl; 
				  
				  
				  
				  
				  string h1("Hector Villa Lobos");
				  string h2("hector villa lobos");
				  
				  cout << "Dwa stringi \n[" << h1 
					  << "] oraz [" << h2 << "]\n";
				  
				  cout << "Przy porownaniu wrazliwym na wielkosc liter..." << endl;
				  if(h1 != h2)
				  {
					  cout << " -> sa rozne " << endl;
				  }
				  
				  cout << "Przy porownaniu NIEwrazliwym na wielkosc liter..." 
					  << endl;
				  
				  if(zrob_male_p(h1) == zrob_male_a(h2))
				  {
					  cout << " - sa identyczne" << endl;
				  }
				  
				  
			  }
			  
		  }
		  
		  cout << "Napisz jakies slowo na sam koniec: ";
		  string slowo99;
		  cin >> slowo99;
}

//------------------------------------------------------------------
void biblioteczna(const char * wsk)
{
	cout	<< "Przyslany mi C-string to: "
		<< wsk
		<< endl;
}
//**********************************************************
void otwarcie_pliku(const char * wsk)
{
	cout << "Otwieram plik: "
		<< wsk
		<< endl;
}
//**********************************************************
string zrob_male_p(string dany)
{
	// recznie
	for(int i = 0 ; i < dany.length() ; i++)
	{
		dany[i] = tolower(dany[i]);  // tylko przypisanie
	}
	
	return dany;
	
}
//*********************************************************
string zrob_male_a(string dany)
{
	transform(dany.begin(), dany.end(), dany.begin(), tolower);
	return dany;
}
//**********************************************************

