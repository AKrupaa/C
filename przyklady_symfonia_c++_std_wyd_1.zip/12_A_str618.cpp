//***************************************************
// Program z paragrafu   12.a (str 618)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
#include <string>
using namespace std;


//--------------------------
class kwadrat;                // deklaracja zapowiadajaca

////////////////////////////////////////////////////////
class punkt {
     int  x, y;
     string nazwa;
public :
     punkt(int a, int b,string opis);
     void ruch(int n, int m)  { x += n; y += m; }
     // ... moze cos jeszcze ...

     friend int sedzia(punkt & p, kwadrat & k);   //
};
////////////////////////////////////////////////////////
class kwadrat  {
     int  x, y,
          bok;
     string nazwa;
public :
     kwadrat(int a, int b, int dd, string opis);
     // ... moze cos jeszcze ...

     friend int sedzia (punkt & p, kwadrat & k);      //
};
////////////////////////////////////////////////////////
punkt::punkt(int a, int b,string opis)     // konstruktor
{
     x = a; y = b;
     nazwa = opis;
}
/******************************************************/
kwadrat::kwadrat(int a, int b, int dd, string opis)
                                             // konstruktor
{      
	x = a; y = b;
     bok = dd;
     nazwa = opis;
}
/******************************************************/
// z ta funkcja przyjaznia sie obie klasy
int sedzia (punkt & pt, kwadrat & kw)                    //

{
     if( (pt.x >= kw.x)  &&  (pt.x <= (kw.x + kw.bok) )
          &&
           (pt.y >= kw.y)  &&  (pt.y <= (kw.y + kw.bok) )
       )
     {
          cout << pt.nazwa << " lezy na tle "
               << kw.nazwa << endl;
          return 1;
     }else {
          cout << "AUT ! " << pt.nazwa
               << " jest na zewnatrz "
               << kw.nazwa << endl;
          return 0;
     }
}
/******************************************************/
int main()
{
     kwadrat     bo(10,10, 40, "boiska");
     punkt     pi( 20, 20, "pilka");

     sedzia(pi, bo );                                   //
     cout << "kopiemy pilke !\n";
     while(sedzia(pi, bo)){
          pi.ruch(20,20);
     }


}




