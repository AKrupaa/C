//***************************************************
// Program z paragrafu   12.b (str 622)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;
#include <string>


//---------------------------
class punkt ;                // deklaracja zapowiadajaca

/////////////////////////////////////////////////////////
class kwadrat  {
     int  x, y,
          bok ;
     string  nazwa;
public :
     kwadrat(int a, int b, int dd, string opis) ;
     // ... moze cos jeszcze ...

     int sedzia (punkt & p) ;                         //
} ;
/////////////////////////////////////////////////////////
class punkt {
     int  x, y ;
     string  nazwa;
public :
     punkt(int a, int b,string opis) ;
     void ruch(int n, int m)  { x += n ; y += m ; }
     // ... moze cos jeszcze ...

     friend int kwadrat::sedzia(punkt & p) ;             //
} ;
////////////////////////////////////////////////////////
punkt::punkt(int a, int b,string opis)     // konstruktor
{
     x = a; 
	 y = b;
     nazwa = opis;
}
/*******************************************************/
kwadrat::kwadrat(int a, int b, int dd, string opis)
                                             // konstruktor
{      x = a ; y = b ;
     bok = dd ;
     nazwa = opis;
}
/******************************************************/
int kwadrat::sedzia (punkt & pt)                     //

{
     if( (pt.x >= x)  && (pt.x <= (x + bok) )       //

          &&
           (pt.y >= y)  && (pt.y <= (y + bok) )
       )
     {
          cout << pt.nazwa << " lezy na tle "
               << nazwa << endl ;
          return 1 ;
     }else {
          cout << "AUT ! " << pt.nazwa
               << " jest na zewnatrz "
               << nazwa << endl ;
          return 0 ;
     }
}
/*******************************************************/
int main()
{
     kwadrat     bo(10,10, 40, "boiska") ;
     punkt     pi( 20, 20, "pilka");
     bo.sedzia(pi);                                    //

}


