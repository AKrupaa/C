//***************************************************
// Program z paragrafu   13.4 (str 641.)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
 
#include <iostream>
using namespace std ;

const int max_urzadz = 15 ;
const int max_czujn = 10 ;

// tablica na wyniki pomiar�w
int detektor[max_urzadz][max_czujn] ;    // `1


bool odczytaj_zdarzenie();    
void analizuj_zdarzenie();
unsigned long pobierz_slowo();

//********************************************************************************
int main()
{

    cout << "Program analizujacy ciagle dostarczane dane pomiarowe" << endl;

    while(odczytaj_zdarzenie() ) 		// odebranie danych    `2
    {
        // pokazanie i ewentualna analiza
        analizuj_zdarzenie();								// `3
    }

    cout << "Nie ma wiecej danych, konczymy " << endl;

}
//**************************************************************************************
bool odczytaj_zdarzenie()			// `4
{

	//==============================================================
	// W tej funkcji lokalnie definiujemy sobie struktur� oraz uni�.
	// O tym, �e tak wolno porozmawiamy na stronie ...
	//==============================================================

	// Struktura skladajaca sie z pol bitowych opisujace rozklad bitow
	// przychodzacych z ukladow elektronicznych VXI
	struct slowo_vxi						// `5
	{
		unsigned int dana			:  16;
		unsigned int urzadzenie		:  8;
		unsigned int czujnik		:  6;
		unsigned int 				:  2;
	};

	// unia anonimowa, kt�ra pozowoli na konwersj� ca�ego s�owa na "pokawa�kowane"
	union										//`6
	{
		unsigned long	cale;
		slowo_vxi		vxi;
	};

	cout << "Wczytywanie nastepnego zdarzenia...\n" ;

	// p�tla wczytuj�ca wiele s��w nale��cych do jednego "zdarzenia"
    while(1)
    {
        cale = pobierz_slowo();										// `7

        if(!cale)  // jesli jest tam zero, to...					// `8
            return false; // koniec ca�ego pomiaru


		// ponizej korzystamy juz z postaci vxi - czyli informacji poci�tej na pola bitowe
        if(vxi.urzadzenie == 0xf8)									// `9
        {
            // taki wyj�tkowy numer urzadzenia oznacza, �e tak naprawd� nie jest 
			// to slowo z dan� pomiarowa, ale �e to tak zwany "znacznik konca zdarzenia".
            cout << "Koniec odczytu danych zdarzenia nr " 
					<< vxi.dana << endl;							// `10
            return true;   // zakonczyly sie poprawnie dane tego zdarzenia 
        }
        else
        {
			// Tu jestesmy gdy jest to zwyk�e s�owo z wynikiem pomiaru

			// Najpierw sprawdzamy czy numery urz�dzenia i czujnika maja sens
            if(	vxi.urzadzenie> max_urzadz || vxi.czujnik >= max_czujn)  // `11
            {
                continue;     // zla dana, taki detektor nie istnieje, pomijamy
            }

            // dobra dana, pakujemy do okre�lonego detektora 
            detektor[vxi.urzadzenie][vxi.czujnik] = vxi.dana;     // `12
        }
    }

}
//**************************************************************************
void analizuj_zdarzenie()				// `13
{
    cout << "Analiza zdarzenia. Zadzialaly:  " << endl;
    
	for(int u = 0 ; u < max_urzadz ; u++)
	{
        for(int c = 0 ; c < max_czujn ; c++)
        {
            if(detektor[u][c])
            {
                cout<< "\turzadzenie " << u << ", czujnik " << c
					<< ", odczyt = " << detektor[u][c] << endl;
				// tu udajemy ze analizujemy
				// .....
            }
        }
	}

	// po analizie tego zdarzenia zeruremy przygotowujac sie na nastepne.
    memset(detektor, 0, sizeof(detektor)) ;  // wyzerowanie calej tablicy `14
}
//*************************************************************************
unsigned long pobierz_slowo()				// `15
{
    // ta funkcja imituje odobieranie danych z elektronicznego ukladu akwizycji danych
    unsigned long slowo[] = 
	{
             0x4060658, 0x60201ff, 0x9058c, 0xf80000, 
			 328457, 100729404, 0xf80001,
             197827, 134417127, 84087033, 50927293, 
			 16848207, 17105686, 16847128,
             0xf80002,
             0 // ostanie slowo puste, oznacza koniec danych pomiarowych
    };

    static int licznik ;
    return slowo[licznik++] ;
}

 

 