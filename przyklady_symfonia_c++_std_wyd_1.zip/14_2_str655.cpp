//***************************************************
// Program z paragrafu   14.2 (str 655)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
//             i tutaj nie daje sie skompilowa� bo jest protest( niesluszny)
//             przy linijce (10)


#include <iostream>
using namespace std;

int xyz = 10; 				// zmienna globalna 		  `1
void zwykla();
/*******************************************************/
main()
{
	zwykla();
	// lokalik BBB; 					 		  `2
}
/*******************************************************/
void zwykla()
{
	int xyz = 15; 								// `3
	int lokal_autom; 								// `4
	static float lokal_stat = 77; 					// `5

	class lokalik
	{
	public :
		//	static int sss; 	// b��d - klasa nie mo�e 	 `6
						// mie� sk�adnik�w statycznych
		void lok_funskl()
		{
			cout << "Jestem w funkcji inline (lok_funsk) \n"
				//	<< "xyz= " << xyz << endl 	 	// `7
					<<"  Globalne  ::xyz = " << ::xyz      // `8
				// << lokal_autom // bd ! 		// `9
				<< "\n  Lokalne statyczne  lokal_stat = "
				<< lokal_stat 	 // o.k. !		// `10 Tu VC++ protestuje
				<< endl;
		}
	};
	//---------------------------------

	cout << "Jestem w zwyklej funkcji \n";
	lokalik A; 								// `11
	A.lok_funskl(); 						 // `12
}



/*
Jestem w zwyklej funkcji
Jestem w funkcji inline (lok_funsk)
  Globalne  ::xyz = 10
  Lokalne statyczne  lokal_stat = 77


*/