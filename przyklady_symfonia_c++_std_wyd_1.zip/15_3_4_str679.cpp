//***************************************************
// Program z paragrafu   15.3.4 (str 679)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;

////////////////////////////////////////////////////////////
class kl {
public :
     int   a ;
     float b ;
     char  c ;
     // -------------------------------konstruktor
     kl(int i, float x, char z )
     { a = i ; b = x ; c = z ;}
} ;
/////////////////////////////////////////////////////////
void wypis(kl ) ;
int main()
{
     kl   obiektA(1, 3.14, 'x'),

          obiektB(2, 1.41, 's') ;

     wypis(obiektA);
     wypis(obiektB);

     wypis( kl(3, 7.77, 'l') ) ;          //
}
//*******************************************************
void wypis(kl sk)
{
     cout << " a= " << sk.a << " b= " << sk.b
          << " c= " << sk.c << endl ;
}

/************************************************************
************************************************************/
