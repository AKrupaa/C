//***************************************************
// Program z paragrafu   15.7 (str 690)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


// Program gruntownie zmieniony. Po szczegoly odsylam do przykladu
// 14_1_1.cpp gdzie poraz pierwszy pojawila sie klasa przyrzad.
// Zmiany zostaly zrobione po to, by w programie wystepowaly
// wylacznie funkcje z biblioteki standardowej.


#include "przyrzad.h"						// `1


extern ekran_alfanumeryczny ekran;
void zwloka(int sekund) ;
/////////////////////////////////////////////////////////
class panel {                                    // `2

           int poz_x ;
     const int poz_y ;

     przyrzad predkosciomierz ;
     int *wsk1 ;

     przyrzad drugi ;
     int *wsk2 ;

public :
     // konstruktor
     panel(    string nazw,                            // `3
               int x, int y,
               int * zrodlo_sygnalu1,
               int * zrodlo_sygnalu2,
               string opis2, string jedn2) ;
     // destruktor
     ~panel();
     // zwykla funkcja skladowa
     void aktualizuj() ;
};
///////////////// koniec def klasy panel ////////////////
// -----------------definicja konstruktora
panel::panel(  string nazw, int x, int y,                // `4
               int * zrodlo_sygnalu1,
               int * zrodlo_sygnalu2,
               string opis2, string jedn2)
                    : poz_x(x),           // <---lista incjalizacyjna.
                      poz_y(y),
                      predkosciomierz(x, y+3,
                                   "Predkosc", "km/h"),
                      drugi(x, y+7, opis2, jedn2)
{
     wsk1  = zrodlo_sygnalu1 ,                         // `5
     wsk2 =  zrodlo_sygnalu2 ;
     ekran.napisz(poz_x, poz_y, nazw);
}
/*******************************************************/
panel::~panel()                                          // `6
{
     ekran.napisz(poz_x, poz_y, "  - ZLOMOWANY -   ");
}
/*******************************************************/
void panel:: aktualizuj()
{
     predkosciomierz.zmien_wskazanie(*wsk1) ;                      // `7
     drugi.zmien_wskazanie(*wsk2) ;
}
/*******************************************************/
int main()
{
int  predkosc = 0,
     azymut = 270 ;

     ekran.wyczysc() ;    // skasowanie dotychczasowej tresci ekranu

     // definicja obiektu klasy panel                            // `8

     panel kabina("Panel pilota", 1,2, &predkosc, &azymut,
                    "kurs ", "stopni");

     int i = 0 ;
     for(i = 0 ; i < 50 ; i++)
     {
          // imitujemy zmiane w czasie lotu
          predkosc = 60 + i ;
          azymut = 270 + i%3 ;

          // panel to pokazuje
          kabina.aktualizuj() ;                           // `9
          zwloka(1) ;
     }
     // --- bawimy sie dalej -----

     int      paliwo = 500 ;

     // definiujemy drugi panel   // `10
     panel maszynownia("Panel mechanika", 35,2, &predkosc,
                    &paliwo, "Zuzycie paliwa", "litrow");

     for( ; i < 100 ; i++)
     {
          // imitujemy zmiane w czasie lotu
          predkosc = 60 + i ;
          azymut = 270 + i%3 ;
          paliwo -- ;

          kabina.aktualizuj() ;
          maszynownia.aktualizuj() ;
           zwloka(1) ;
     }
}

// ********************************************************
// Funkcj� zwloka, kt�ra powoduje w programie
// zw�ok� czasowa o d�ugo�ci zadanej liczby sekund
// ********************************************************
void zwloka(int sekund)   
{
	time_t poczatkowy_czas = time(NULL) ;

	// ta p�tla wykonuje si� dop�ki nie minie zadana liczba sekund
	while(time(NULL) - poczatkowy_czas < sekund);   // cia�o puste
}
