 // ***************************************************
// Program z paragrafu   15.9.7 (str 712)
// ***************************************************
// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std ;
#include <string>


/////////////////////////////////////////////////////////
class wizytowka 
{
     string *wsk_nazw ;                       // `1
     string *wsk_imie ;
public :

     // konstruktor
     wizytowka(string na = "", string im = "") ;
	 
     // destruktor
     ~wizytowka() ;

     void personalia() 
	 {
          cout << *wsk_imie << " " 
			   << *wsk_nazw << endl ;
     }
     //-----------
     void zmiana_nazwiska(string nowe)
     {
          *wsk_nazw = nowe;
     }
	 /****************
	 tak powinien wygl�da� konstruktor kopiuj�cy
	 wizytowka::wizytowka(wizytowka &wzor) 	
	 { 		
		 wsk_nazw = new string; 		
		 *wsk_nazw = *(wzor.wsk_nazw);  		
		 wsk_imie = new string; 		
		 *wsk_imie = *(wzor.wsk_imie); 	
	 }
	 *****************/
} ;
/////////////////////////////////////////////////////////
// definicja konstruktora
wizytowka::wizytowka(string im, string na)
{
     wsk_nazw = new string;                      // `2
     *wsk_nazw = na;                          // `3

     wsk_imie = new string;
     *wsk_imie = im;
}
/*******************************************************/
// ------------- definicja destruktora ----
wizytowka::~wizytowka()
{
     delete  wsk_nazw ;          // `4
     delete  wsk_imie ;
}
/*******************************************************/
int main()
{
	wizytowka fizyk( "Albert", "Einstein") ;                // `5
	wizytowka kolega = fizyk ;                             // `6


	cout << "Po utworzeniu blizniaczego obiektu oba "
               "zwieraja nazwiska\n" ;

    fizyk.personalia();                              // `7
    kolega.personalia();

     // m�j kolega nazywa sie naprawde Albert Metz
     kolega.zmiana_nazwiska("Metz");                    // `8

     cout << "\nPo zmianie nazwiska kolegi brzmi ono : ";
     kolega.personalia();                              // `9

     cout << "Tymczasem niemodyfikowany fizyk"
               " nazywa sie : " ;
     fizyk.personalia();                              // `10




}


/************************************************************

------------------------------------------------------
Jeszcze jedna uwaga. Otoz poniewaz w tym, blednym przykladzie
doprowadzamy do tego ze wskazniki obu obiektow pokazuja na te
same tablice - zatem w trakcie destrukcji tych obietkow
nastapia komplikacje. Pierwszy niszczony obiekt skasuje
rezerwacje tych tablic. Drugi oczywiscie musi zrobic to samo,
a poniewaz jego wskazniki pokazuja na te same tablice
wiec dojdzie do rzeczy zabronionej - czyli do powtornego
kasowania tej samej rezerwacji pamieci. 
Zatem na samo pozegnanie - program moze jeszcze zglosic blad pamieci.



************************************************************/
