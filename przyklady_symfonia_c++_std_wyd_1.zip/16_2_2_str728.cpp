//***************************************************
// Program z paragrafu   16.2.2 (str 728)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std;

#include <string>
///////////////////////////////////////////////////////
class stacje_kolejki 
{
     double km;          // na ktorym kilometrze trasy
     int glebokosc;
     string nazwa;
     string przesiadki;
public:
     // ---------- konstruktor                                    // `1
     stacje_kolejki(double kk, int gg, string nn, string pp = "");
     // ---------- konstruktor domniemany
     stacje_kolejki();
     // ---------- zwykla funkcja skladowa
     void gdzie_jestesmy();

};
//////////////////////////////////////////////////////
stacje_kolejki::stacje_kolejki(double kk, int gg, string nn, string pp)
               : km(kk), glebokosc(gg), nazwa(nn), przesiadki(pp)             // `2
{
 
}
/****************************************************/
stacje_kolejki::stacje_kolejki() : km(0), glebokosc(0) 
                                   // konstruktor domniemany `3
{
     nazwa = "Nie nazwana jeszcze";
     przesiadki = "";   
}
/****************************************************/
void stacje_kolejki::gdzie_jestesmy()                    // `4
{
     cout << "Stacja : " << nazwa << endl;
     if(przesiadki.size())                    
     {
          cout << "\tPrzesiadki : " << przesiadki << endl;
     }
}
/******************************************************/
int main()
{               
		
	stacje_kolejki ostatnia =
               stacje_kolejki (22, 0, "Wansee", "118 Bus" ); // `5

     ostatnia.gdzie_jestesmy();
     cout << "********************\n";

	const int ile_stacji = 7;
	stacje_kolejki przystanek[ile_stacji] =       // `6

     {
     stacje_kolejki (0,  5, "Fredrichstrasse", "Linia U6"),
     stacje_kolejki (),
     stacje_kolejki (),
     stacje_kolejki (5.7, 4, "Tiergarten"),
     stacje_kolejki (8,   4, "ZOO", "Linie U1 i U9")
     };

     for(int i = 0 ; i < ile_stacji ; i++)
     {
          przystanek[i].gdzie_jestesmy();
     }
}


/************************************************************

************************************************************/
