//***************************************************
// Program z paragrafu  17.2.1 wsk funkcji skladowej (str 742)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0




#include <iostream>
#include <string>
using namespace std;

////////////////////////////////////////////////////////////
class  zdarzenie			// `1
{
public:
	int sygnalX1;
	int sygnalX44;
	int sygnalX8;
	int sygnalX2;
	int polka_zielona;
	int polka_niebieska;
	int polka_rozowa; 
	int polka_biala;
	int polka_fioletowa;
	int polka_turkusowa;
	int polka_bezowa;
};
/////////////////////////////////
zdarzenie *biezace_zdarzenie;   // `2

////////////////////////////////
class komora_drutowa   // `3
{
	string nazwa;

	int zdarzenie::*wL;
	int zdarzenie::*wP;
	int zdarzenie::*wG;
	int zdarzenie::*wD;
	//...

public:
	komora_drutowa(string nnn,     // `4
			int zdarzenie::*wsk_lewy, 
			int zdarzenie::*wsk_prawy, 
			int zdarzenie::*wsk_gora, 
			int zdarzenie::*wsk_dol) 
				: nazwa(nnn), wL(wsk_lewy), wP(wsk_prawy)
	{
		wG = wsk_gora;
		wD = wsk_dol;
	};

	//---------------------------------
	void analizuj()    // `5
	{ 
		cout << "Dla " << nazwa << " elektroda lewa = " 
			 << biezace_zdarzenie->*wL    // `6
			 << endl;
	}
};
/////////////////////////////////////////////////////////////////////

//*******************************************************************
komora_drutowa  mw41("mw41",    // `7
			&zdarzenie::sygnalX1, 
			&zdarzenie::polka_zielona, 
			&zdarzenie::polka_niebieska,  
			&zdarzenie::polka_biala);

komora_drutowa  mw42("mw42",    // `8
			&zdarzenie::polka_rozowa, 
			&zdarzenie::polka_fioletowa, 
			&zdarzenie::polka_bezowa, 
			&zdarzenie::polka_turkusowa);

//********************************************************************

void dokonaj_pomiaru();
//*********************************************************************
main()
{

	for(int i = 0 ; i < 5 ; i++)   // `9
	{
		cout << "Pomiar nr " << i << endl;
		dokonaj_pomiaru();	  // `10
		mw41.analizuj();   // `11
		mw42.analizuj();
	}
	
	delete biezace_zdarzenie; // `12
}
//**********************************************************************
void dokonaj_pomiaru() // `13
{	
	if(biezace_zdarzenie)  // `14
	{
		delete biezace_zdarzenie;  
	}

	biezace_zdarzenie = new zdarzenie; // `15

	// Dalej juz wielkie oszustwo.
	// Imitacja odczytu wynik�w z ukladow elektronicznych 
	// i "ustawienie tych wynik�w na odpowiednich polkach"
	static int m ;							// `16
	m += 100;

	biezace_zdarzenie->sygnalX1		= m + 1; // `17
	biezace_zdarzenie->sygnalX44	= m + 2;
	biezace_zdarzenie->sygnalX8		= m + 3;
	biezace_zdarzenie->sygnalX2		= m + 4;
	biezace_zdarzenie->polka_zielona	= m + 5;
	biezace_zdarzenie->polka_niebieska	= m + 6;
	biezace_zdarzenie->polka_rozowa		= m + 7; 
	biezace_zdarzenie->polka_biala		= m + 8;
	biezace_zdarzenie->polka_fioletowa	= m + 9;
	biezace_zdarzenie->polka_turkusowa	= m + 10;
	biezace_zdarzenie->polka_bezowa		= m + 11;
}