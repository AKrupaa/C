//***************************************************
// Program z paragrafu 17.3.1  wsk funkcji skladowej (str 750)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
using namespace std;

////////////////////////////////////////////////////////////////
class K				// Korektor dopplerowski   `1
{
public:										// `2

    //============================================
    // Dwa sposoby oszacowania pr�dko�ci jonu
    double tryb_przyblizony(int x)      // `3
    {
        cout << "przyblizone" << endl ;
        return 0.4 / x ;
    }
    double tryb_dokladny   (int x)   // `4
    {
        cout << "dokladne" << endl;
        return 0.456777 / x;
    }

    //============================================
    // Trzy sposoby oszacowania trajektorii lotu
    double sposob_Samita(double a, double b)  // `5
    {
        cout << "sposobem Samita" << endl ;
        return 0.314 + a + b ;
    }

    double sposob_Juergena(double a, double b) // `6
    {
        cout << "sposobem Juregena" << endl ;
        return 0.414  + a + b ;
    }

    double sposob_Pietera(double a, double b) // `7
    {
        cout << "sposobem Pietera" << endl ;
        return 0.514  + a + b ;
    }



    double licz_poprawke(double energia,	// `8
                         double (K::*wskf_predkosc)(int),
                         double (K::*wskf_tor)(double, double) );

};
////////////////////////////////////////////////////////////////////
// funkcja sk�adowa
double  K::licz_poprawke(double energia,	// `9
                         double (K::*wskf_predkosc)(int),
                         double (K::*wskf_tor)(double, double) )
{

    cout << "Procedura obliczania poprawki...\n"
    << "   Szacowanie predkosci : " ;
    // -------------------------------------------------------
    // Szacowanie pr�dko�ci za pomoca funkcji, kt�r� wybra� u�ytkownik
    int zmierzona_predkosc = 6; // <-- z jakiego pomiaru  // `10
    double beta = (this->*wskf_predkosc)(zmierzona_predkosc);  // `11

    cout << "   Szacowanie  trajektorii: " ;
    //-------------------------------------------------------
    // �ledzenie trajektorii jonu wylatuj�cego wed�ug innego
    // sposobu, wybranego przez u�ytkownika
    double wspx = 0.12;   // np. dane z kom�r drutowych?   // `12
    double wspy = 0.64;

    // Dla uproszczenia tylko dwa argumenty

    double cosinus_kata = (this->*wskf_tor)(wspx, wspy);   // `13

    // imitacja w�a�ciwych oblicze�
    double eneria_skorygowana = energia * (1- (beta * cosinus_kata)); // `14
    return eneria_skorygowana; // `15
}
//************************************************************************
K doppler ; // `16
//************************************************************************
int main(int argc, char* argv[])
{
    cout << "Obliczanie poprawki dopplerowskiej" << endl;

    cout << "Podaj wartosc energii zmierzonej? : " ;
    double Em = 0;
    cin >> Em;

    double Ep = 0; // zmienna na energi� poprawion�

    // jeden wariant
    Ep= doppler.licz_poprawke(Em, &K::tryb_przyblizony, &K::sposob_Samita);  // `17
    cout << "A) Po poprawce, prawdziwa wartosc = " << Ep << endl;

    // drugi wariant
    Ep= doppler.licz_poprawke(Em, &K::tryb_dokladny, &K::sposob_Pietera);   // `18
    cout << "B) Po poprawce, prawdziwa wartosc = " << Ep << endl;

    // trzeci wariant
    Ep= doppler.licz_poprawke(Em, &K::tryb_dokladny, &K::sposob_Juergena);  // `19
    cout << "C) Po poprawce, prawdziwa wartosc = " << Ep << endl;

}

/*
Obliczanie poprawki dopplerowskiej
Podaj wartosc energii zmierzonej? : 1000
Procedura obliczania poprawki...
   Szacowanie predkosci : przyblizone
   Szacowanie  trajektorii: sposobem Samita
A) Po poprawce, prawdziwa wartosc = 928.4
Procedura obliczania poprawki...
   Szacowanie predkosci : dokladne
   Szacowanie  trajektorii: sposobem Pietera
B) Po poprawce, prawdziwa wartosc = 903.011
Procedura obliczania poprawki...
   Szacowanie predkosci : dokladne
   Szacowanie  trajektorii: sposobem Juregena
C) Po poprawce, prawdziwa wartosc = 910.624

  */

