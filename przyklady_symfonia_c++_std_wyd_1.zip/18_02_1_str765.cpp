 //***************************************************
// Program z paragrafu 18.2.1 (str 765)
//***************************************************
// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;
#include <string>


///////////////////////////////////////////////////////
class zespolona
{
     double rzeczyw ;
     double urojon ;
public :

     // dwa konstruktory konwertujace
     explicit zespolona(double r = 0, double i = 0)   //`1
		 : rzeczyw(r),urojon(i)
     { }

    friend void pokaz(const zespolona z);   // `2
} ;
///////////////////////////////////////////////////////
 void pokaz(const zespolona z)
 {
          cout << "Liczba zespolona: ["
			<< z.rzeczyw
			<< ", "
			<< z.urojon
			<< "] \n" ;
 }
/*******************************************************/
int main()
{
	zespolona a;	// `3
	zespolona b(2.4);  // `4
//	zespolona c	= 2.5;	// <-niejawne wywoanie konstruktora `5
	zespolona d	= zespolona(2.6);   // `6
	zespolona *wsk_e	= new zespolona(2.7); // `7
	zespolona f		= (zespolona)2.8;    // `8
	zespolona g		= static_cast<zespolona>(2.9); // `9

	//--------------

	pokaz(a);
	pokaz(b);
//	pokaz(c);  // (to jest konsekwencja innej niemo�liwo�ci) `9
	pokaz(d);
	pokaz(*wsk_e);
	pokaz(f);
	pokaz(g);
//	pokaz(3.0);   // <-- przy explicit niemozliwe `10
}


/* 
*/