//***************************************************
// Program z paragrafu   18.3 (str 773)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std;

#include <string>

class numer;                                             // `3
///////////////////////////////////////////////////////
class zespol 
{
	double rzeczyw;                                   // `1
     double urojon;
public :
     // dwa konstruktory konwertuj�ce
     zespol(double r = 0, double i = 0):rzeczyw(r),urojon(i)
     { }
     zespol(numer ob);                                   // `2

     operator double() { return rzeczyw; }             // `4
     operator numer();
     void pokaz()
     {
          cout << "\tLiczba zespolona: (" << rzeczyw
               << ", " << urojon << ") \n";
     }
     friend zespol dodaj(zespol a, zespol b);
};
///////////////////////////////////////////////////////
class numer 
{
     double n;
     string opis;                                     // `5
     friend zespol::zespol(numer);
     friend void plakietka(numer);
public:
     numer(double k, string t = "opis domniemany")
		 : n(k), opis(t)		// `6
     { }
     operator double() { return n; }                    // `7
};
///////////////////////////////////////////////////////
zespol::zespol(numer ob) : rzeczyw(ob.n), urojon(0)
{ 
/* puste cia�o, bo wszystko zrobione za pomoc� listy inicjalizacyjnej
*/ 
}
/******************************************************/
zespol::operator numer()
{
  // pomagamy sobie wywo�uj�c konstruktor (ale ju� nie konwertuj�cy,
  // bo wywo�ywany z 2 argumentami).

  return numer(rzeczyw, "powstal z zespolonej");
}
/******************************************************/
// deklaracje funkcji globalnych
void pole_kwadratu(double bok);
void plakietka(numer nnn);
zespol dodaj(zespol a, zespol b);
/*******************************************************/
int main()
{
     // definicje trzech obiekt�w
     double     x = 3.21;
     numer     nr(44, "a imie jego");
     zespol     z(6, -2);

	

     // wywo�ania funkcji pole_kwadratu(double); // `8

     pole_kwadratu(x);               // niepotrzebna zadna konwersja

     // poni�sze wywo�ania nie sa dopasowane, ale mimo to mo�liwe, bo
     // kompilator samoczynnie zastosuje nasze konwersje
     pole_kwadratu(nr);        // operator konwersji numer-->double

     pole_kwadratu(z);        // operator konwersji zespol-->double


     // ------------------------------------------------
     zespol      z2(4,5),               // def 2 roboczych obiekt�w
               wynik;

     // wywo�ania funkcji dodaj(zespol, zespol) `9

     wynik = dodaj(z, z2);          // niepotrzebna �adna konwersja
     wynik.pokaz();

     // poni�sze wywo�ania nie s� dopasowane, ale mimo to mo�liwe, bo
     // kompilator samoczynnie zastosuje nasze konwersje

     wynik = dodaj(z, x);// konstr. konwertuj�cy double-->zespol
     wynik.pokaz();
     wynik = dodaj(z, nr);// konstr. konwertuj�cy numer-->zespol
     wynik.pokaz();

     //--------------------------------------------------------------


     // wywo�ania funkcji plakietka(numer); `10

     plakietka(nr);

     // poni�sze wywo�ania nie s� dopasowane, ale mimo to mozliwe, bo
     // kompilator samoczynnie zastosuje nasze konwersje
     plakietka(x);          // konstr. konwertujacy double --> numer
     plakietka(z);          // operator konwersji zespol --> numer

}
/*****************************************************/
zespol dodaj(zespol a, zespol b)
{
     zespol chwilowy(a.rzeczyw + b.rzeczyw,
                      a.urojon  + b.urojon);
     return chwilowy;
}
/*****************************************************/
void plakietka(numer nnn)
{
     cout << "*****************************" << endl;
     cout << "***                       ***\r"
          << "*** " << nnn.opis << endl;
     cout << "***                       ***\r"
          << "***             " << nnn.n << endl;
     cout << "*****************************" << endl;
}
/*****************************************************/
void pole_kwadratu(double bok)
{
     cout << "Pole kwadratu o boku " << bok
          << " wynosi " << (bok * bok) << endl;
}
/******************************************************/

