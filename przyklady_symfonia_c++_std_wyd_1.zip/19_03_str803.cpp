//***************************************************
// Program z paragrafu   19.3 (str 803)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;


const int rozmiar = 1024 ;                              //
/////////////////////////////////////////////////////////
class widmo
{
public:
     int kanal[rozmiar] ;                                //
     // ---------- konstruktor

     widmo(int wart = 0) ;
     // ---------- przeladowany operator
     widmo  operator+(int ) ;
};
/*******************************************************/
widmo::widmo(int wart)                                   //

{
     for(int i = 0 ; i < rozmiar ; i++)
          kanal[i] = wart ;
}
/*******************************************************/
widmo widmo::operator+(int liczba)
{
widmo rezultat ;
     for(int i = 0 ; i < rozmiar ; i++)
          rezultat.kanal[i] = kanal[i] + liczba ;      //
     return rezultat ;
}
/*******************************************************/
int main()
{
widmo kobalt(5) ;                                        //
widmo nowe ;                                              //
      nowe = kobalt + 100 ;                           //

      cout << "Przykladowo patrzymy na na kanal 44. \n"
                "Widmo 'kobalt' ma tam : "
           <<  kobalt.kanal[44]
           << "\na w widmie 'nowe' jest tam : "
           <<  nowe.kanal[44] << endl ;

      nowe = nowe + 700 ;                              //

      cout <<"A teraz w kanale 44 obiektu 'nowe' jest : "
           << nowe.kanal[44] << endl ;
}

/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------



************************************************************/

