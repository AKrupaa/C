//***************************************************
// Program z paragrafu   19.11.1 (str 830)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0
#include <iostream>
using namespace std ;
#include <string>           

/////////////////////////////////////////////////////////
class persona						// `1
{
	string * wsk_nazwiska;			// `2
	double * tablica_prob;			// `3
	int ile_prob;					// `4
	enum { max_elem = 10 };		// `5
public:
	persona(string n);					// konstruktor
	
	persona(const persona &wzor) ;		// konstr. kopiujacy
	~persona();							// destruktor
	void info(const string) ;

	void dodaj_czas_proby(double wart);
	
	// operator przypisania
	persona &  operator=(const persona &wzor) ;
} ;
////////////////////////////////////////////////////////
persona::persona(string miano)     // `6 
{	
	wsk_nazwiska = new string(miano);  
	tablica_prob = new double[max_elem];
	ile_prob = 0;

	//---------------
	cout << " (Pracuje konstruktor zwykly dla: "	<< miano << ")" 
		<< endl ;
}
/******************************************************/
persona::persona(const persona &wzor)			// `7
{
	// proste przepisanie warto�ci
    ile_prob = wzor.ile_prob;
	
	// stworzenie obiektu klasy string, 
	wsk_nazwiska = new string;
	// a potem przepisanie zawarto�ci ze wzorca
	*wsk_nazwiska = *(wzor.wsk_nazwiska);
	
	// stworzenie tablicy 
	tablica_prob = new double[max_elem];
	// przepisanie zawarto�ci z obiektu wzorcowego
	for(int i = 0 ; i < max_elem ; i++)
	{
		tablica_prob[i] = wzor.tablica_prob[i];
	}
	
	//----------------
	cout << " (Pracuje konstruktor kopiujacy, " 
		"kopiowanie z obiektu " << *wsk_nazwiska
		<< ")" << endl ;
}
/******************************************************/
persona::~persona()									// `8
{
	delete [] tablica_prob ;
	delete wsk_nazwiska ;
}
/******************************************************/
void persona::info(const string txt)   // `9
{
	cout << " " << txt << " "
		<< *wsk_nazwiska 
		<< ", czas prob: ";
	for(int i = 0 ; i < ile_prob ; i++)
	{
		cout << tablica_prob[i] << " h, ";
	}
	cout << endl;
}
/*******************************************************/
void persona::dodaj_czas_proby(double wart)   // `10
{
	if(ile_prob < max_elem)
	{
		tablica_prob[ile_prob++] = wart;
	}
}
/*******************************************************/
persona & persona::operator=(const persona &wzor) // `11
{                                                     
	// ## Czesc 1) Sprawdzenie czy to nie kopiowsnie siebie samego ## `12
	if(&wzor == this) return *this;

	// ## Czesc 2) "Destruktorowa" ######################### `13
	
	delete [] tablica_prob ;
	delete wsk_nazwiska ;

	// ## Czesc 3) "Konstruktorowa (konst. kopiujacy)" ###  `14

	// proste przepisanie warto�ci
	ile_prob = wzor.ile_prob;

	// stworzenie obiektu klasy string, 
	wsk_nazwiska = new string;
	// a potem przepisanie zawarto�ci ze wzorca
	*wsk_nazwiska = *(wzor.wsk_nazwiska);
	
	// stworzenie tablicy 
	tablica_prob = new double[max_elem];
	// przepisanie zawarto�ci z obiektu wzorcowego
	for(int i = 0 ; i < max_elem ; i++)
	{
		tablica_prob[i] = wzor.tablica_prob[i];
	}
	
	
	//------------------
	cout << " (Pracuje operator= czyli operator przypisania)\n" ;
	return *this ;			// `16
}
/******************************************************/
int main()
{
	cout << "Definicje 'pianista', i 'skrzypek' \n" ;
	
	persona pianista("Dino" );           // `17
	persona skrzypek("Xavier");

	// kolejne dni prob ---------------
	pianista.dodaj_czas_proby(5.5);
	skrzypek.dodaj_czas_proby(6.0);

	pianista.dodaj_czas_proby(4);
	skrzypek.dodaj_czas_proby(5);
	// koniec prob -------
	
	cout << "\nDefinicja 'dyrygent' : \n" ;
	
	persona dyrygent = pianista ;   // konstruktor kopiujacy  // `18
	
	cout << "\nOto tresc w obiektach\n" ;

	pianista.info("Pianista:");                              // 19
	skrzypek.info("Skrzypek:");
	dyrygent.info("Dyrygent to:");
	
	cout << "\nZabawy z przypisywaniem ---\n" ;
	
	dyrygent = skrzypek ;                              // `20
	dyrygent.info("Dyrygent:");

	cout << "Zmiana dyrygenta\n";
	dyrygent = pianista ;
	dyrygent.info("Dyrygent:");
	
	cout << "'Kaskadowe' przypisanie ----------\n" ;
	dyrygent = skrzypek = pianista ;                  // `21
	
	// sprawdzamy co to dalo
	pianista.info("Pianista:");
	skrzypek.info("Skrzypek:");
	dyrygent.info("Dyrygent:");
	
}
