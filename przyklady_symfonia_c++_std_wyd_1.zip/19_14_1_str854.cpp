//***************************************************
// Program z paragrafu   19.14.1 (str 854)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std;

/////////////////////////////////////////////////////////
class wekt {
public :
     float x, y, z;
     //--- konstruktor -----
     wekt(float a, float b, float c)
                         : x(a), y(b), z(c)             //
     { }
     //--- kilka zwyklych funkcji skladowych
     void podwojenie()
     {
          x *= 2;     y *= 2;     z *= 2;
     }
     //-----
     void pokaz()
     {
          cout << "x= "<< x << ", y= "<< y
               <<", z= "<< z << endl;
     }
};
/////////////////////////////////////////////////////////
class spryciarz {
     wekt *wsk;                                         //
     wekt * (pamietnik[10]);                        //
     int uzycie;
public :
     // ---- operator przypisania----------

     void operator=(wekt* w)                             //
     {
          wsk = w;
     }
     // --- konstruktor (takze domniemany !)
     spryciarz(wekt * adr= NULL);                      //
     // -------- przeladowanie operatora ->
     wekt * operator->();

     void statystyka(void);
};
/*******************************************************/
spryciarz::spryciarz(wekt * adr)  :      wsk(adr),
                                   uzycie(0)             //
{
     for(int i = 0 ; i < 10 ; i++)pamietnik[i] = NULL;
}
/*******************************************************/
wekt * spryciarz::operator->()                          //
{
     //---- akcja sprytna : wpisujemy do akt !
     pamietnik[uzycie] = wsk;
     uzycie = (++uzycie) % 10;                         //
     // ---- zwykla akcja--------

     return wsk;
}
/*******************************************************/
void spryciarz::statystyka(void)
{
     cout << "Ostatnie 10 wypadkow uzycia odbylo sie "
                "dla obiektow \no adresach :\n";
     for(int i=0 ; i < 10 ; i++){
          cout << pamietnik[ ( (uzycie) + i) % 10 ]  //
               << ((i==4)? "\n" : ", ");
     }
     cout << endl;
}
/******************************************************/
int main()
{
float m;
wekt  www(1, 1, 1);

wekt *zwykly_wsk;                                        //
spryciarz zreczny_wsk;                              //

     zwykly_wsk = &www;
     zreczny_wsk = &www;                            //

     cout << "Operacja za pomoca zwyklego wskaznika \n";
     m =   zwykly_wsk -> x ;
     cout << "m = " << m << endl ;
     cout << "Operacja za pomoca zrecznego wskaznika \n" ;
     m =   zreczny_wsk -> x ;                       //
     cout << "m = " << m << endl ;

wekt      w2(2, 2, 2),
          w3(3, 3, 3),
          w4(44, 10, 1) ;

	

     zreczny_wsk = &w2 ;
     zreczny_wsk->podwojenie() ;                       //
     zreczny_wsk->pokaz();

     zreczny_wsk = &w3 ;
     zreczny_wsk->podwojenie() ;
     zreczny_wsk->pokaz();

     zreczny_wsk = &w4 ;
     zreczny_wsk->podwojenie() ;
     zreczny_wsk->pokaz();

     zreczny_wsk.statystyka() ;                        //

     zreczny_wsk = &www ;
     zreczny_wsk->pokaz();

     zreczny_wsk.statystyka() ;


}




/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std;


-----------------------------------------------------
int main()
------------------------------------------------------



************************************************************/


