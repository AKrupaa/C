//***************************************************
// Program z paragrafu   19.17. (str 865)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std;

/////////////////////////////////////////////////////////
class wekt 
{
public :
     float x, y, z;
     //--- konstruktor -----
     wekt(float a=0, float b=0, float c=0)
                         : x(a), y(b), z(c)             // `1
     { }
     //--- kilka zwyklych funkcji skladowych
     void podwojenie()
     {
          x *= 2;     y *= 2;     z *= 2;
     }
     //-----
     void pokaz()
     {
          cout << "\tx= "<< x << ", y= "<< y
               <<", z= "<< z << endl;
     }
	 void * wekt::operator new(size_t rozmiar); // `2
	 void wekt::operator delete(void * wsk);   // `3
	 
	 static  void * wekt::operator new[](size_t rozmiar); // `4
	 static  void wekt::operator delete[](void * wsk);  // `5
};
/////////////////////////////////////////////////////////
//***********************************************************
void * wekt::operator new(size_t rozmiar)   // `6
{ 
	cout << "Kreuje pojedynczy obiekt , rozmiar= " << rozmiar << endl; 
	return (new char[rozmiar]); 
}
//***********************************************************
void wekt::operator delete(void * wsk)  // `7
{ 
	cout << "Kasuje pojedynczy obiekt\n"; 
	delete wsk; 
}
//*************************************************************
void * wekt::operator new[](size_t rozmiar) // `8
{ 
	cout << "Kreuje tablice obiektow klasy wekt, rozmiar= " << rozmiar << endl; 
	return (new char[rozmiar]); 
}
//*************************************************************
//*************************************************************
void wekt::operator delete[] (void * wsk)   // `9
{ 
	cout << "Kasuje tablice obiektow klasy wekt\n"; 
	delete [] wsk; 
}
//*************************************************************
/**************************************************************/
int main()
{
	cout << "Operatorem new z klasy wektor..." << endl;

	wekt *w1;                                        //
	w1 = new wekt(0, 1, 3);   //  `10
	w1->pokaz();

	cout << "\nOperatorem new globalnym..." << endl;
	wekt * w2 = ::new wekt(2, 2, 2);     // `11
	w2->pokaz();
	
	cout << "\nOperatorem new[] z klasy wektor..." << endl;
	wekt * w3 = new wekt[10];		// `12
	w3->pokaz();

	cout << "-------- Przystepujemy do kasowania -----" << endl;

	
	delete w1;			// `13
	cout << "Po skasowaniu w1 (pojedynczego)\n" << endl;
  
	::delete w2;  // ``14
	cout << "Po skasowaniu w2 (globalnego)\n" << endl;
	
	delete [] w3;		// `15
	cout << "Po skasowaniu w3 (tablicy)\n" << endl;
  
//	cout << "zakonczenie programu" << endl;
  
}

