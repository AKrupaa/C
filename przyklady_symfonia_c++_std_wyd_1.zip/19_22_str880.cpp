//***************************************************
// Program z paragrafu   19.22 (str 880)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

/////////////////////////////////////////////////////////
class wektorek {
public :
     float x, y, z ;
     //--- konstruktor
     wektorek(float a=0, float b=0, float c=0): x(a),
                                                  y(b), z(c)
     { }
} ;
/////////////////////////////////////////////////////////
/*******************************************************/
// globalna funkcja operatorowa
// realizujaca przeladowania << dla naszej klasy wektorek
/*******************************************************/
ostream & operator<<(ostream & ekran , wektorek & w)//

{
     ekran << "wspolrzedne wektora : "  ;
     ekran << "(" ;
     ekran << w.x ;                                        //

     ekran << ", " << w.y                                //
           << ", " << w.z << ")" ;
     return ekran ;                                     //
}
/*******************************************************/
int main()
{
     wektorek     w(1,2,3) ,
               v ,
               k(-10, -20, 100);

     cout << "Oto nasze wektory \nwektor w -" ;
     cout << w ;                                         //

     cout << "\nwektor v -" << v
          << "\nwektor k -" << k
          << endl ;

     cout << "Wywolanie jawne \n" ;
     operator<<( cout , w) ;                            //
 }




/************************************************************

************************************************************/


