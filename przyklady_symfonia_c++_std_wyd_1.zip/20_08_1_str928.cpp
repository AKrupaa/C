//***************************************************
// Program z paragrafu   20.8.1 (str 928)
//***************************************************

// Sprawdzony na Linuksie,  kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

/////////////////////////////////////////////////////////
class samochod
{
protected :
     int  a ;
public:
     samochod(int arg) : a(arg)
     {
          cout << "Konstruktor samochodu\n" ;
     } ;
} ;
/////////////////////////////////////////////////////////
class lodka {
protected :
     int b ;
public:
     lodka(int x) : b(x) {
          cout << "Konstruktor lodki \n" ;
     }
} ;
/////////////////////////////////////////////////////////
class amfibia : public samochod, public lodka           //
{
public :
     amfibia() :   samochod(1991) , lodka(4)           //
     {
          cout << "Konstruktor amfibii \n" ;
     }

     void pisz_skladniki()  {
          cout << "Oto odziedziczone skladniki\na = "
               << a << "\t b = " << b << endl ;
     }
} ;
/*******************************************************/
int main()
{
amfibia  aaa ;
     aaa.pisz_skladniki();
}



/************************************************************
Zmiany sa w nastepujacych linijkach
------------------------------------------------------
#include <iostream>
using namespace std ;

------------------------------------------------------

-------------------------------------------------------
int main()
------------------------------------------------------



************************************************************/


