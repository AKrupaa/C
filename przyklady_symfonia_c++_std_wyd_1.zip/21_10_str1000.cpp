//***************************************************
// Program z paragrafu   20.10 (str 1000)
//***************************************************

// Sprawdzony na Linuksie,    kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0


#include <iostream>
#include <string>
using namespace std ;

/////////////////////////////////////////////////////////
class instrum 
{
public :
      virtual void wydaj_dzwiek()      
	  {
          cout << "cisza" ;
     }
     // ----wirtualny destruktor
     virtual ~instrum()                                  // `1
     {
          cout << "Destruktor instrumentu \n" ;

     }
} ;
/////////////////////////////////////////////////////////
class skrzypce : public instrum                          // `2
{
		string nazwa ;
		int *tabl_numerow;
public :
     // - konstruktor------------------------

     skrzypce(string firma, int rok_produkcji, int nr_seryjny)
		 :nazwa(firma) 
     {
		tabl_numerow = new int[2];    // `4
		tabl_numerow[0] = rok_produkcji;
		tabl_numerow[1] = nr_seryjny;  
     }
     //--- destruktor (wirtualny) -----------------

     ~skrzypce()
     {
          cout << "Destruktor skrzypiec + " ;
          delete [] tabl_numerow ;                              // `5
     }
     // ----------------------------

     void wydaj_dzwiek()
     {
          cout << "tirli-tirli ("
               << nazwa << ")\n" ;
     }
} ;
/////////////////////////////////////////////////////////
class gwizdek :public instrum                          // `3
{
public :
     void wydaj_dzwiek()     
	 {
          cout << "fiu-fiu \n" ;
     }
};
/////////////////////////////////////////////////////////
class gitara : public instrum 
{
     string nazwa ;
	 int *tabl_numerow;
public :
     // - konstruktor-------------------

     gitara(string firma, int rok_produkcji, int nr_seryjny)
		 :nazwa(firma) 
     {
		tabl_numerow = new int[2];  // `4
		tabl_numerow[0] = rok_produkcji;
		tabl_numerow[1] = nr_seryjny;  
     }
     //- destruktor (wirtualny) ---------------

     ~gitara()
     {
          cout << "Destruktor gitary + " ;
          delete [] tabl_numerow ;    // `5
     }
     // --------------------------

     void wydaj_dzwiek()
     {
          cout << "brzdek-brzdek   ("
               << nazwa << ")\n" ;
     }
} ;
/*******************************************************/
int main()
{
     cout << "Definiujemy w zapasie pamieci\n"
               "trzy instrumenty orkiestry\n  " ;

     instrum *pierwszy = new skrzypce("Stradivarius", 1736, 630) ;
     instrum *drugi    = new gitara("Ramirez", 1997, 14822) ;
     instrum *trzeci   = new gwizdek ;                 // `6

     cout << "Gramy polimorficznie ! \n" ;

     pierwszy->wydaj_dzwiek() ;                         // `7
     drugi   ->wydaj_dzwiek() ;
     trzeci  ->wydaj_dzwiek() ;

     cout << "\nKoncert sie skonczyl, "
               "likwidujemy instrumenty\n\n" ;

     delete pierwszy ;                                   // `8
     cout << string(50, '*') << endl;
     delete drugi ;
     cout << string(50, '*') << endl;
     delete trzeci ;

	 return 0;
}
/*******************************************************/





