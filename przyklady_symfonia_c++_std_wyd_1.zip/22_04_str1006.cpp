//***************************************************
// Program z paragrafu   22.4 (str 1026)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

/******************************************************/
int main()
{
int i;
float f ;
char tekst [80] ;

     cout << "Podaj liczbe int : " ;
     cin >> i ;
     cout << "Podales : " << i << endl ;

     cout << "Podaj liczbe float : " ;
     cin >> f ;
     cout << "Podales : " << f << endl ;

     cout << "Napisz wyraz  : " ;
     cin >> tekst ;
     cout << "Napisales ***" << tekst << "***\n" ;
}
/*****************************************************/



