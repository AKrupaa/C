//***************************************************
// Program z paragrafu   22.7 (str 1032)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

/////////////////////////////////////////////////////////
class wekt {
public :
     float x, y, z ;
} ;
/////////////////////////////////////////////////////////
/*******************************************************/
// globalne funkcje operatorowe
// realizujace przeladowania << oraz >> dla klasy wekt
/*******************************************************/
ostream& operator<<(ostream& strumien_wyj, wekt w)     //

{
     strumien_wyj << w.x << " " << w.y << " " << w.z  ;
     return strumien_wyj ;
}
/*******************************************************/
istream& operator>>(istream& strumien_wej, wekt &w)     //

{
     strumien_wej >> w.x >> w.y >> w.z ;
     return strumien_wej ;
}
/*******************************************************/
int main()
{
wekt a, b ;

     cout << "Podaj wspolrzedne wektora a : " ;
     cin >> a ;
     cout << "Podaj wspolrzedne wektora b : " ;
     cin >> b ;

     cout << "Wektor a ma wspolrzedne [" << a << "]"
          << endl ;
     cout << "Wektor b ma wspolrzedne [" << b << "]" ;
}

//************************************************************

