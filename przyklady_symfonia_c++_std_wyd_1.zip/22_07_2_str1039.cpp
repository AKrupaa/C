//***************************************************
// Program z paragrafu   22.7.2 (str 1039)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

/////////////////////////////////////////////////////////
class samochod 
{
public:
     int rok_produkcji ;
     virtual void rzecznik (ostream & strum);
} ;
/////////////////////////////////////////////////////////
class mercedes : public samochod {
public:
     string model ;
     void rzecznik(ostream & strum) ;
} ;
/*******************************************************/
// realizacja operatora << dla klasy podstawowej
/*******************************************************/
ostream & operator<<(ostream &strum , samochod &x)     //

{
     x.rzecznik(strum) ;                              //
     return strum ;
}
/*******************************************************/
//     realizacje funkcji wirtualnych
/*******************************************************/
void samochod::rzecznik(ostream & strum)
{
     strum << rok_produkcji  ;
}
/*******************************************************/
void mercedes::rzecznik(ostream & strum)
{
     samochod::rzecznik(strum);
     strum << " " << model ;
}
/*******************************************************/
int main()
{

samochod a, b ;

          a.rok_produkcji =  1990 ;
          b.rok_produkcji =  1992 ;

mercedes m ;

          m.rok_produkcji =  1991;
          m.model = "sportowy" ;

     cout << a  << endl ;
     cout << b  << endl ;
     cout << m  << endl ;
}



/************************************************************

************************************************************/


