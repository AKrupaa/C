// ***************************************************
// Program z paragrafu   22.11.5 (str 1080)
// ***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP,  kompilator: Microsoft Visual C++ 6.0



#include <iostream>
#include <string>
using namespace std ;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class naszManip														
{
	int arg;										
public:
	naszManip(int argument) : arg(argument)   	
	{ }
	//-----------------------
	void dzialaj(ostream &os)  const		
	{
		os.width(arg);
	}
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ostream & operator <<(ostream & strum, naszManip const & man)
 												
{
	man.dzialaj(strum); 									
	return strum ;
}
/*************************************************************/
int main()
{
	string nazwa("Musee d'Orsay");

	cout << "#" << nazwa << "#\n";
	cout << "#" << naszManip(18) << nazwa << "#\n";    

}



