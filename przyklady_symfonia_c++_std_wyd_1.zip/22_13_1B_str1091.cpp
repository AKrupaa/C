//***************************************************
// Program z paragrafu   22.13.2.b (str 1091)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

/*******************************************************/
int main()
{
char kuferek[10] = { "xxxxxxxxx" };

     cout << "Napisz max 9 znakow: ";
     cin.getline(kuferek, sizeof(kuferek), 's' ) ;

     cout << "Oto zawartosc elementow kuferka :\n" ;
     for(unsigned int i = 0 ; i < sizeof(kuferek) ; i ++)
     {
               cout << "kuferek[" << i << "]= "
                    << kuferek[i] << endl  ;
     }
	 
     cout << "Nastepnie wyjety znak : "
          << (char)(cin.get()) ;
}



/************************************************************
 

************************************************************/


