//***************************************************
// Program z paragrafu   22.13.3 (str 1095)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;
 
/*************************************************************/
int main() 
{ 
char kuferek[10]; 
char skrytka[10]; 
 
	cout << "Napisz okolo 10 znakow: "; 
	cin.get(kuferek, 4).ignore(2).get(skrytka, 10); 
	cout << "\nW kuferku jest:"<< kuferek 
		<< ", w skrytce jest:" << skrytka 
		<< "\na dwa znaki zignorowalem " << endl; 
}




/************************************************************

************************************************************/


