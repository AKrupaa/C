//***************************************************
// Program z paragrafu   22.13.4.a (str 1096)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

/*******************************************************/
int main()
{
char tablica[200] ;

     cout << "Napisz jakies zdanie : "  ;
     cin.get(tablica, sizeof(tablica) , 'x' );        //

     cout << "Ze strumienia wyjeta zostalo :"
          << ( cin.gcount() )
          << " znakow,  \noto zdanie :"
          << tablica << endl ;
}



/************************************************************

************************************************************/


