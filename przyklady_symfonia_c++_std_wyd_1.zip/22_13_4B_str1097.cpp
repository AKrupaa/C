//***************************************************
// Program z paragrafu   22.13.4.b (str 1097)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

#include <cctype>                                      //

/*******************************************************/
int main()
{
char nazwa[200] ;
float x ;
int zwiastun ;
     cout << "napisz liczbe lub nazwe : " ;
     zwiastun = cin.peek() ;                           //

     if(isdigit(zwiastun) ){                           //
          cin >> x ;                                     //
          cout << "Byla to liczba : " << x << endl ;
     }else {
          cin >> nazwa ;                                 //
          cout << "Byla to nazwa : " << nazwa << endl ;
     }
}



/************************************************************

************************************************************/


