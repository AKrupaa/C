//***************************************************
// Program z paragrafu   22.14 (str 1103)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;
#include <fstream>
/******************************************************/
int main()
{
ofstream osrodek ;                              // etap

     osrodek.open("ksiezyc.tmp") ;              // etap
     osrodek << "misja" ;                       // etap
     osrodek.close();                          // etap
}
/************************************************************

************************************************************/


