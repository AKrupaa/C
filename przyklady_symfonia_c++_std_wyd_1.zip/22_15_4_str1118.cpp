//***************************************************
// Program z paragrafu   22.15.4 (str 1118)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;
#include <fstream>
#include <string>


class slowo_na_e 
{
public:   
   string wyraz;
};
////////////////////////////////////////////////////////
istream & operator >>(istream & str, slowo_na_e & w)
{
     str >> w.wyraz ;
     if(w.wyraz[0] != 'e')
	 {
		  str.setstate(ios::failbit) ;// `1a
		  // stary spos�b by� taki:
          // str.clear(str.rdstate() | ios::failbit  ) ;// `1b
     }
     return str ;
}
/******************************************************/
int main()
{
slowo_na_e   pierwsze, drugie, trzecie ;

     while(1){
          cout << "Podaj trzy slowa na litere 'e' : " ;
          cin >> pierwsze >> drugie >> trzecie ;         //

          if(!cin) {
               cout << "\nZle  ! Od poczatku : " ;
               cin.clear(cin.rdstate() & ~ios::failbit);//
          }
          else break ;     // jesli poprawnie
      }
}




/************************************************************

************************************************************/


