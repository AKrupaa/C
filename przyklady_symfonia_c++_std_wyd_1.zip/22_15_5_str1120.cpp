// ***************************************************
// Program z paragrafu	 22.15.5 (str 1120)
// ***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std;
#include <fstream>
#include <string>
//************************************************************
int main()
{
	ifstream strum; 	   // definicja strumienia do pracy z plikiem
	string	nazwa_pliku;
	
	// -------- niepowodzenie w otwieraniu pliku do czytania
	// mo�e ustawi� flag� b��du ios::failbit
	// w razie, gdy plik nie istnieje. Strumie� tkwi w�wczas w stanie b��du.
	// Aby ponowi� pr�b� otwarcia pliku, flag� t� trzeba najpierw skasowa�.
	
	
	bool sukces = false;
	
	while(!sukces)
	{
		cout << "Podaj nazwe pliku: ";
		cin >> nazwa_pliku;
		cout << endl;		  // kosmetyka ekranu
		
		// pr�ba otwarcia
		strum.open(nazwa_pliku.c_str(), ios::in);		   // `1
		
		// czy si� uda�o ?
		if(!strum)				// czyli inaczej: strum.fail()
		{
			cout << "Blad otwarcia pliku: "
				<< nazwa_pliku << endl;
			// Skoro pr�ba otwarcia nie uda�a si� to strumie�
			// jest w stanie b��du !!!";
			// musimy usun�� stan b��du strumienia
			
			
			strum.clear(strum.rdstate() & ~ios::failbit); // <- kasowanie flagi `2
			
			// strumie� ju� jest w porz�dku. W kolejnym obiegu p�tli
			cout << "Ponowiamy probe...\n";
		}
		else
		{						  // uda�o si� otworzy�,
			sukces = true;			 // wiec p�tl� mo�na zako�czy�
			cout << "Plik poprawnie zostal otworzony do czytania\n" 
				<< string(50, '#') << endl;
		}
	}								// koniec p�tli while
	
	//#######################################################################
	// -----------------operacje czytania mog� wywo�a� ustawienie flagi b��du
	// ios::eofbit w wypadku, gdy dojdziemy do ko�ca pliku
	// i mimo to pr�bujemy czyta� nadal. Aby dalej pracowa�
	// z tym strumieniem musimy skasowa� t� flag� b��du
	// ( a potem ewentualnie ustawi� kursor czytania
	// w poprawne miejsce)
	//#######################################################################
	
	int numer;
	char znak;
	
	do
	{
		cout << "Podaj numer bajtu ktory chcesz poznac: ";
		cin >> numer;
		// pozycjonujemy kursor czytania na tym bajcie
		strum.seekg(numer);								// `5
		
		znak = strum.get(); 							// `6
		if(strum.eof() )
		{
			sukces = false;
			cout << "Blad pozycjonowania, "
					"prawdopodobnie plik\n\t jest krotszy"
					" niz " << numer << " bajtow\n";
			// strumie� tkwi w stanie b��du ios::eofbit,
			// oraz r�wnocze�nie ios::failbit
			// trzeba go skasowa�
			
			strum.clear(strum.rdstate() & ~(ios::eofbit | ios::failbit) ); // <--- zmiana `7
			cout << "(Podaj mniejsza liczbe)\n";
			// b�dzie ponowny obieg p�tli
			
		}
		else 
		{
			sukces = true;
			cout	<< "Ten bajt to hexadecymalnie: " 
				<< showbase << hex << (int) znak
				<< ", a jako znak ASCII: '"<< znak << "'\n"
				<< string(50, '#') 
				<< endl;
		}
	}while(!sukces);
	
	//#########################################################################
	// ------------------pr�ba formatowanego wczytania liczby w sytuacji, gdy
	// w�a�nie oczekuje na wczytanie cos, co liczba nie jest,
	// - wprowadzi strumie� w stan b��du ios::failbit
	//#########################################################################
	
	cout << "Proba wczytanie nastepnych znakow jako cyfr liczby..." << endl;
	int liczba;
	// instrukcja wczytania liczby - rozpocznie czytac zaraz po
	// wczytanym poprzednio bajcie
	strum >> liczba;		  // `8
	// czy sie udalo ?
	if(strum.fail() )
	{									  // nie !
		cout <<  "Blad failbit, bo najblizsze "
			"bajty\n\t nie moga "
			"byc wczytane jako liczba\n";
		
		// Aby to cos w�wczas wczyta� jako string
		// nale�y skasowa� ustawiona flag� b��du
		
		strum.clear(strum.rdstate() & ~ios::failbit);   // `9
		// strumie� nadaje si� do pracy, a to cos, co go
		// zatka�o, nadal czeka na wczytania
		
		string slowo;
		strum >> slowo;
		cout << "Jest to slowo: "<< slowo << endl;
		
	}else{
		// tak !
		cout << "Pomyslnie wczytana liczba: "
			<< liczba << endl;
	}
	// dalsza praca z plikiem ....
}

/*************************************************************/

