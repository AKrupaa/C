//***************************************************
// Program z paragrafu   22.16 (str 1123)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std;
#include <fstream>
#include <string>

//*******************************************************
int main()
{
	string plik_a;
	string plik_b;
	
	// ------------------------------------------------
	cout << "Podaj nazwe pliku wejsciowego : ";
	cin >> plik_a;
	ifstream czyt(plik_a.c_str() );   // `1
	if(!czyt)
	{
		cout << "Nie moge otworzyc takiego pliku ";
		return 1;
	}
	// ------------------------------------------------
	cout << "Podaj nazwe pliku wyjsciowego : ";
	cin >> plik_b;
	
	ofstream pisz(plik_b.c_str());                         // `2
	if(!pisz)
	{
		cout << "Nie moge otworzyc takiego pliku ";
		return 1;
	}
	// ----- akcja przepisywania ----------------------
	char c;
	while(czyt.get(c))                               // `3
	{
		if(!pisz.put(c) )                           // `4
		{
			cout << "Blad pisania ! \n";
			break;
		}
	}
	// -------- koniec, sprawdzam pow�d zakonczenia ---------
	if(!czyt.eof() )                                 // `5
		{
			cout << "Blad czytania\n";
	}
}



/************************************************************

  
************************************************************/


