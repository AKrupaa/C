// ***************************************************
// Program z paragrafu	 22.17  str. 1127
// ***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std;
#include <fstream>
#include <string>

void czytaj_40_liczb_int(ifstream & s);
void biezace_ustawienie(ifstream &s);
//************************************************************
int main()
{
	ifstream strum; 	   // definicja strumienia do pracy z plikiem
	string	nazwa_pliku("t.tmp");
	
	
	strum.open(nazwa_pliku.c_str(), ios::in);		   // `1
	
	// czy si� uda�o ?
	if(!strum)				// czyli inaczej: strum.fail()
	{
		cout << "Blad otwarcia pliku: "
			<< nazwa_pliku << endl;			
		return -1; 
	}
	
	
	biezace_ustawienie(strum);                      // `2
	cout << "Zmiana powodow rzucenia wyjatku" << endl;
	strum.exceptions(ios::failbit | ios::badbit);   // `3
	
	biezace_ustawienie(strum);				// `4
	
	
	try
	{
		czytaj_40_liczb_int(strum); // `5
	}
	catch(ios::failure const & kapsula)
	{
		cout << "Nie udalo sie bo: " 
				<< kapsula.what() << endl; // `6
				
	}
	
}
//***************************************************************
void czytaj_40_liczb_int(ifstream & s)
{
	for(int i = 0; i < 40; i++)
	{
		int wartosc;
		s >> wartosc;   // `7
		cout << "(" << wartosc << ")";
	}
	
}
//************************************************************
void biezace_ustawienie(ifstream &s)   // `8
{
	cout << "Wyjatek bedzie rzucony, gdy ustawione sa flagi:\n";
	
	ios::io_state  rzuc_gdy = s.exceptions();   // `9

 	cout << "ios::failbit - ";
	if(rzuc_gdy & ios::failbit) 
		cout << "TAK\n";
	else 
		cout << "nie\n";
	
	cout << "ios::eofbit - ";
	if(rzuc_gdy & ios::eofbit) 
		cout << "TAK\n";
	else 
		cout << "nie\n";
	
	cout << "ios::badbit - ";
	if(rzuc_gdy & ios::badbit) 
		cout << "TAK\n";
	else 
		cout << "nie\n";	
}
//***********************************************************
/*
Tre�c pliku t.tmp

1  2  3  4 
20  45  55.2  70
100 200  300

*/

