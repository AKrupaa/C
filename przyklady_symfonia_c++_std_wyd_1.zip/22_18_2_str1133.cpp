//***************************************************
// Program z paragrafu   22.18.2 (str 1133)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std ;

#include <fstream>
#include <string>

/******************************************************/
int main()
{
string tekst = 
      "Coz, wedlug Ben-Alego,\n"
      "czarnomistrza Krakowa\n"
      "nie jest to nic wielkiego\n"
      "dorozke zaczarowac." ;

  // Otwieram istniejacy plik i go zeruje,
  // lub jesli go nie ma - tworze go 
  fstream strum("wiersz.tmp", ios::trunc | ios::in | ios::out);
  if(!strum)
  {
    cout << "Blad otwarcia pliku " << endl;
    return -1 ;
  }

  strum << tekst ;

  // pozycjonowanie kursora pisania na literze 25
  strum.seekp(25) ;
  strum << "ABCDE" ;

  // pozycjonowanie kursora pisania na znaku 6 od konca
  strum.seekp(-6, ios::end) ;
  strum << "X" ;
}
/************************************************************
************************************************************/


