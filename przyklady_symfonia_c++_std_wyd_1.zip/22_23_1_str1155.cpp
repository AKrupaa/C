//***************************************************
// Program z paragrafu   22.23.1 (str 1155)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// !!! Robi problemy na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std;
#include <iomanip>

#include <sstream>   // <-- bo  uzywamy ostringstream  // `1
void pomiar(string nazwa);
void odczyt(const char * nazwa);
/*******************************************************/
int main()
{
	int nr_silnika = 4;
	double temperat = 156.7123;
	
	ostringstream skomunikat ;  // `2
	
	// a teraz wlasciwe wypisanie
	
	skomunikat << "Awaria silnika "<< setw(2) << nr_silnika
								<< ", temperatura oleju " << fixed << setprecision(2)
								<< temperat << " stopni C \n";  // `3
	
	if(!skomunikat) cout << "Jakis blad pracy strumienia"<< endl; // `4
	
	// dopisujemy dalej
	skomunikat.fill('.');           // `5
	skomunikat.width(25);
	skomunikat << "Musisz cos zrobic !!!\n" ; // `6
	
	cout << "Aby sie przekonac czy w tablicy "
		"znalazl sie\nrzeczywiscie zadany tekst "
		"wypisujemy jej tresc\nna ekran \n";
	cout	<< "*******************************************\n"
		<< skomunikat.str()   // `7
		<< "*******************************************\n";
	
	
	skomunikat.seekp(8, ios_base::beg);    // `8
	
	skomunikat << "XYZ";
	cout << "W takim stringu mozna nawet pozycjonowac wskaznik pisania:\n"
		<< skomunikat.str();   // `9
	
	
	skomunikat.str("Nowa wstepna tresc niszczaca stara");   // `10
	// Uwaga, je��i uzywasz kompilator VC++ 6.0 to powy�sza wywo�anie funkcji 
	// mo�e w spowodowa� b��d w trakcie wykonywania destruktora tego obiektu

	cout << skomunikat.str() << endl;
	
	double pi = 3.1415;
	skomunikat << pi;
	skomunikat << ",  a  dwa pi = " << 2 * pi ;   // `11
	cout << skomunikat.str() << endl;
	
	
	cout << "\nBudujemy inny string, potrzebna nam nazwe jakiegos pliku" << endl;
	ostringstream   snazwa_pliku("Probka_", ios::ate);  // `12
	
	// Dla wielbicieli VC++ v. 6.0 inna wersja poprzedniej instrukcji
	// ostringstream   snazwa_pliku;     
	// snazwa_pliku << "Probka_";     
	
	
	int nr_zestawu = 167;
	int nr_dnia = 9;
	int nr_miesiaca = 5;
	int nr_roku = 2005;
	
	
	snazwa_pliku
		<< setfill('0') <<  setw(5) << nr_zestawu
		<< "_z_" << setw(2) << nr_dnia
		<< "_" << setw(2) << nr_miesiaca
		<< "_" << setw(4) << nr_roku
		<< ".dane" ;						// `13
	
	pomiar(snazwa_pliku.str());  // `14
	odczyt(snazwa_pliku.str().c_str());	// `15
}
//***************************************************************
void pomiar(string nazwa)  // `16
{
	cout << "Pomiar, a wynik zapisywany w pliku:\n " 
		<< nazwa << endl;
}
//***************************************************************
void odczyt(const char * nazwa)  // `17
{
	cout << "Odczyt pomiaru, zapisanego w pliku:\n " 
		<< nazwa << endl;
}
/*---
Aby sie przekonac czy w tablicy znalazl sie
rzeczywiscie zadany tekst wypisujemy jej tresc
na ekran
*******************************************
Awaria silnika  4, temperatura oleju 156.71 stopni C
...Musisz cos zrobic !!!
*******************************************
W takim stringu mozna nawet pozycjonowac wskaznik pisania:
Awaria sXYZika  4, temperatura oleju 156.71 stopni C
...Musisz cos zrobic !!!
Nowa wstepna tresc niszczaca stara
3.14,  a  dwa pi = 6.28czaca stara

Budujemy inny string, potrzebna nam nazwe jakiegos pliku
Pomiar, a wynik zapisywany w pliku:
 Probka_00167_z_09_05_2005.dane
Odczyt pomiaru, zapisanego w pliku:
 Probka_00167_z_09_05_2005.dane

*/