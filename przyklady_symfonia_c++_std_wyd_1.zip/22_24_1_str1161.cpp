 //***************************************************
// Program z paragrafu   22.24.1 (str 1161)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
#include <sstream>   // <-- bo  uzywamy istringstream   `1
using namespace std ;

bool szukacz(istringstream & s, string kluczowe, double & zmienna);
/*******************************************************/
int main()
{
	
	double ld ;
	string wyraz; 
	int li;
	char c;
	char tab[] = "Abc";
	
	
	string probka("2157.15 wtorek 0x44");    // `2
	
	istringstream schowek(probka);           // `3
	
	
    schowek >> ld ;			// `4
	cout << "Wczytana ld = " << ld << endl;
	ld = 2 * ld;    // `5
	cout << " 2* ld = " << ld << endl;
	
	schowek >>  wyraz ;   // `6
	cout << "Wczytany wyraz = " << wyraz << endl; 
	
	schowek >> hex >> li;   // `7
	cout << "Wczytana (w zapisie hex) liczba li = "
		<< li << endl;   // `8
	
	
	
	
	cout << "To wczytalismy ze strumienia,\n ktory zawiera: " 
		<< schowek.str() << endl;
	

	
	if(schowek.eof()) 
	{
		cout << "\nUwaga: Flaga ios::eofbit ustawiona!" << endl; 
		schowek.clear( schowek.rdstate() & ~ios::eofbit) ;// `10
	}
	
	// demonstracja mozliwosci pozycjonowania
	
	schowek.seekg(1, ios::beg) ;                       // `11
	schowek.get(c) ;
	cout << "\nwydobyty znak c = " << c << endl ;
	
	
	schowek.seekg(7, ios::cur) ;  // `12
	schowek.get(c) ;
	cout << "Siodmy znak dalej to = " << c << endl ;
	
	schowek.seekg(2);   // `13
	schowek >>ld;
	cout << "Liczba wydobyta w inny sposob: " << ld << endl;
	
	//-------------------
	schowek.str("Honni soit qui mal y pense ");   // `14
	
	cout << "\nZmienilismy tresc strumienia.\n Teraz jest to: "
		<< schowek.str() ;
	
	string cytat;
	getline(schowek, cytat, 'q');  // `15
	cout << "\nWczytane: " << cytat << endl;
	
	
	schowek >> wyraz;   // `16
	cout << "Wczytane: " << wyraz << endl;
	
	
	//---------------------------------------------------------
	
	cout << string(40, '-') << endl;
	
	schowek.str("Czynnik zyromagnetyczny 3.4 wzmocnienie "   // `17
		"linii 72.6 decybele suma wplat 237500 powiekszenie "
		"mikroskopu 580 krotne"	);
	
	
	double x;
	
	if(szukacz(schowek, "powiekszenie mikroskopu", x))    // `18
	{
		cout << "a)  x = " << x << endl;
	}
	
	cout << "\n\nPrzeczytamy teraz inna liczbe" << endl;
	if(szukacz(schowek, "zyromagnetyczny", x))   // `19
	{
		cout << "b)  x = " << x << endl;
	}

	cout << "\n\nPrzeczytamy teraz inna liczbe" << endl;
	if(szukacz(schowek, "modul Younga", x)) // `20
	{
		cout << "b)  x = " << x << endl;
	}

}
//********************************************************************
bool szukacz(istringstream & s, string nazwa_danej, double & zmienna) // `21
{
	string tr = s.str();    // `22
	string:: size_type nr = tr.find(nazwa_danej);  // `23

	if(nr == string::npos)
	{
		cout << "Blad: Nazwa danej >" << nazwa_danej 
			<< "< nie znaleziona" << endl;
		return false ;
	}
	cout << "Nazwa danej znaleziona na pozycji " 
		<< nr << endl;
	
	s.seekg(nr + nazwa_danej.length());  // `24
	
	string k;
	double wartosc ;
	s >> wartosc ;  // `25
	if(!s)   // `26
	{
		cout << "Blad wczytywania wartosci o nazwie " 
			<< nazwa_danej << endl; 
		return false ;
	}
	else
	{
		cout << "Za nazwa\n\t>" << nazwa_danej 
			<< "<\n wczytana wartosc " << wartosc << endl;
		zmienna = wartosc;  // `27
		return true;
	}
}



/*
Wczytana ld = 2157.15
 2* ld = 4314.3
Wczytany wyraz = wtorek
Wczytana (w zapisie hex) liczba li = 68
To wczytalismy ze strumienia,
 ktory zawiera: 2157.15 wtorek 0x44

Uwaga: Flaga ios::eofbit ustawiona!

wydobyty znak c = 1
Siodmy znak dalej to = t
Liczba wydobyta w inny sposob: 57.15

Zmienilismy tresc strumienia.
 Teraz jest to: Honni soit qui mal y pense
Wczytane: Honni soit
Wczytane: ui
----------------------------------------
Nazwa danej znaleziona na pozycji 78
Za nazwa
        >powiekszenie mikroskopu<
 wczytana wartosc 580
a)  x = 580


Przeczytamy teraz inna liczbe
Nazwa danej znaleziona na pozycji 8
Za nazwa
        >zyromagnetyczny<
 wczytana wartosc 3.4
b)  x = 3.4


Przeczytamy teraz inna liczbe
Blad: Nazwa danej >modul Younga< nie znaleziona
  */
