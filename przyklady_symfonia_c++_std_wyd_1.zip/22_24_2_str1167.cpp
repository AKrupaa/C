//***************************************************
// Program z paragrafu   22.24.2 (str 1167)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Sprawdzony na Windows XP, kompilator: Microsoft Visual C++ 6.0

#include <iostream>
using namespace std;
#include <sstream>   // <-- bo  uzywamy istringstream

/*******************************************************/
int main(int argc, char* argv[])                          // `1
{
	double x, z;
	string nazwisko;
	
	cout << "Program " << argv[0] 
		<< "\nMa argumentow: " << argc -1 << endl;
	
	if(argc < 4) 
	{
		cout << "Program nalezy wywo�ac z 3 arguemtami: liczba, wyrazem, liczba" 
			<< endl; 
		return -1;
	}
	
	//================================================
	// Pierwszy argument
	//================================================
	istringstream sp(argv[1]);                               // `2
	sp >> x;                                  // `3	
	cout << "Liczba bedaca pierwszym argumentem: " << x << endl;
	
	//================================================
	// Drugi argument odbieramy innym strumieniem
	//================================================
	istringstream s1(argv[1]);    // `4
	
	s1.str(argv[2]);    
	s1 >> nazwisko;   // `5
	cout << "Wczytane nazwisko = " << nazwisko << endl; 
	
    nazwisko = argv[2];  // `6
	cout << "Wczytane nazwisko = " << nazwisko << endl; 
	
	//===========================================================
	// Trzeci argument dla odmiany wczytamy starym strumieniem sp
	// ale pamietajmy, ze jest on w stanie eofbit
	//===========================================================
	
	if(sp.eof())
	{
		cout << "sp ma ustawiona flage ios::eofbit" << endl;
		sp.clear( sp.rdstate() & ~ios::eofbit) ;    // `7
	}
	sp.str(argv[3]);    // `8
	sp >> z;                              // `9
	
	cout << "Oto wartosci przyjetych parametrow\n"
		<< x << endl
		<< nazwisko << endl
		<< z << endl
		<< "suma tych liczb = " << (x+z) << endl;   // `10
	
	
}


/*
Program C:\symfonia_przyklady\przyklad.exe
Ma argumentow: 3
Ma argumentow: 3
Liczba bedaca pierwszym argumentem: 6.33
Wczytane nazwisko = Goethe
Wczytane nazwisko = Goethe
sp ma ustawiona flage ios::eofbit
Oto wartosci przyjetych parametrow
6.33
Goethe
0.741
suma tych liczb = 7.071
*/

