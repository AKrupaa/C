//***************************************************
// Program z paragrafu   22.25.1 (str 1172)
//***************************************************

// Sprawdzony na Linuksie, kompilator: GNU gcc version 3.3.3 (SuSE Linux)
// Na Windows XP, kompilator: Microsoft Visual C++ 6.0
//   strumien pp nie uszanuje tekstu wstepnego !!!!!!!!! 

#include <iostream>
using namespace std;

#include <sstream>   // <-- bo  uzywamy istringstream

/*******************************************************/
int main()
{
	
	int i =0, j = 0;
	double x =0;
	
	stringstream pp;  // `1
	
	pp << "032 10 45.67 osiem" ;  // `2 
	
	cout << "W strumieniu jest " << pp.str() << endl;
	
	pp >> i;   // `3
	pp >> j >> x;
	
	
	cout << "i = "<< i << ", j = "<< j
		<< ", x = "<< x
		<< "\nIch suma = "<< (i + j + x) << endl;
	
	
	cout << "W strumieniu jest:\n" << pp.str() << endl;
	
	// zaadowanie nowego tekstu
	pp.str("Slowa nie tylko dziwia sie swoim sasiedztwem");  // `4
	cout << "W strumieniu jest:\n " << pp.str() << endl;
	
	
	
	// mozna takze pozycjonowac kursory pisania i czytania
	pp.seekg(16, ios_base::beg);  // wskanik pisania  // `5
	
	// i stosowac funkcje skladowe klas podstawowych
	
	char znak;
	pp.get(znak);
	
	cout << "Znak 16-ty = " << znak << endl;
	
	pp.seekp(20);   // wskanik pisania				// `6
	
	// wpisywanie (zacierajace dotychczasowe znaki)
	pp << "ABCD";									// `7
	cout << "W strumieniu jest:\n " << pp.str() << endl;
	
	
	stringstream hamlet("To be or not ",			// `8
						ios::in | ios::out | ios::ate);
	cout << "W strumieniu hamlet jest:\n "
		<< hamlet.str()
		<< endl;
	
	hamlet << "to be. This is a question" ;  // `9
	
	cout << "Po wpisaniu w strumieniu hamlet jest:\n "
		<< hamlet.str()
		<< endl;
	
	string pierwsze;
	hamlet >> pierwsze ;  // `10
	
	cout << "W strumieniu hamlet jest:\n "
		<< hamlet.str()
		<< "\n a pierwsze slowo to >"
		<< pierwsze << "<"
		<< endl;
	
	
}
// Uwaga, MS VC++ nie uszanuje tekstu wstepnego w strumieniu pp
/*
W strumieniu jest 032 10 45.67 osiem

i = 32, j = 10, x = 45.67
Ich suma = 87.67
W strumieniu jest:
032 10 45.67 osiem

W strumieniu jest:
 Slowa nie tylko dziwia sie swoim sasiedztwem
Znak 16-ty = d
W strumieniu jest:
 Slowa nie tylko dziwABCDie swoim sasiedztwem
W strumieniu hamlet jest:
 To be or not
Po wpisaniu w strumieniu hamlet jest:
 To be or not to be. This is a question
W strumieniu hamlet jest:
 To be or not to be. This is a question
 a pierwsze slowo to >To<


*/

